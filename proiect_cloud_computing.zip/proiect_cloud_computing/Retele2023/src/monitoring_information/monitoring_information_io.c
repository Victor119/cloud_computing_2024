#include <stdlib.h>
#include <stdio.h>

#include "monitoring_information.h"
#include "../common_utils/common_utils.h"


int monitoring_information_log(FILE *fp, struct monitoring_information* monitoring_information) {    
    int num_written_bytes = 0;
    int return_value;

    if ((return_value = fprintf(fp, "{monitoring_time=%lu, ", monitoring_information->monitoring_time)) < 0) {
        return return_value;
    }
    num_written_bytes += return_value;

    // System information
    if ((return_value = system_information_log(fp, monitoring_information->system_information)) < 0) {
        return return_value;
    }
    num_written_bytes += return_value;

    // Processes
    if ((return_value = fprintf(fp, ", number_of_processes=%d, processes=[", monitoring_information->number_of_processes)) < 0) {
        return return_value;
    }
    num_written_bytes += return_value;
    for (int i = 0; i < monitoring_information->number_of_processes; i++) {
        if ((return_value = fprintf(fp, "{")) < 0) {
            return return_value;
        }
        num_written_bytes += return_value;

        if ((return_value = process_log(fp, monitoring_information->processes + i)) < 0) {
            return return_value;
        }
        num_written_bytes += return_value;

        if ((return_value = fprintf(fp, "}")) < 0) {
            return return_value;
        }
        num_written_bytes += return_value;

        if (i < monitoring_information->number_of_processes - 1) {
            if ((return_value = fprintf(fp, ", ")) < 0) {
                return return_value;
            }
            num_written_bytes += return_value;
        }
    }

    if ((return_value = fprintf(fp, "]")) < 0) {
        return return_value;
    }
    num_written_bytes += return_value;

    // Users
    if ((return_value = fprintf(fp, ", number_of_users=%d, users=[", monitoring_information->number_of_users)) < 0) {
        return return_value;
    }
    num_written_bytes += return_value;
    for (int i = 0; i < monitoring_information->number_of_users; i++) {
        if ((return_value = fprintf(fp, "{")) < 0) {
            return return_value;
        }
        num_written_bytes += return_value;

        if ((return_value = user_log(fp, monitoring_information->users + i)) < 0) {
            return return_value;
        }
        num_written_bytes += return_value;

        if ((return_value = fprintf(fp, "}")) < 0) {
            return return_value;
        }
        num_written_bytes += return_value;

        if (i < monitoring_information->number_of_users - 1) {
            if ((return_value = fprintf(fp, ", ")) < 0) {
                return return_value;
            }
            num_written_bytes += return_value;
        }
    }

    if ((return_value = fprintf(fp, "]")) < 0) {
        return return_value;
    }
    num_written_bytes += return_value;

    if ((return_value = fprintf(fp, "}\n")) < 0) {
        return return_value;
    }
    num_written_bytes += return_value;
    
    return num_written_bytes;
}

int monitoring_information_from_log(FILE *fp, struct monitoring_information *monitoring_information) {
    int num_read_arguments = 0;
    int return_value, assert_value;
    char _;
    char object[] = "a monitoring information log";

    if ((assert_value = assert_next_token(fp, '{', 1, object))) {
        return assert_value;
    }
    
    return_value = fscanf(fp, "monitoring_time=%lu, ", &monitoring_information->monitoring_time);
    if ((assert_value = assert_scanf_read_as_expected(return_value, 1, object))) {
        return consume_until_newline(fp);
    }
    num_read_arguments += return_value;

    // System information
    monitoring_information->system_information = (struct system_information *) malloc(sizeof(struct system_information));
    return_value = system_information_from_log(fp, monitoring_information->system_information);
    if ((assert_value = assert_scanf_read_as_expected(return_value, 0, object))) {
        return consume_until_newline(fp);
    }
    num_read_arguments += return_value;

    // Processes
    return_value = fscanf(fp, ", number_of_processes=%d, processes=[", &monitoring_information->number_of_processes);
    if ((assert_value = assert_scanf_read_as_expected(return_value, 1, object))) {
        return consume_until_newline(fp);
    }
    num_read_arguments += return_value;

    monitoring_information->processes = (struct process *) malloc(monitoring_information->number_of_processes * sizeof(struct process));
    for (int i = 0; i < monitoring_information->number_of_processes; i++) {
        if ((assert_value = assert_next_token(fp, '{', 1, object))) {
            return assert_value;
        }

        return_value = process_from_log(fp, monitoring_information->processes + i);
        if ((assert_value = assert_scanf_read_as_expected(return_value, 0, object))) {
            return consume_until_newline(fp);
        }
        num_read_arguments += return_value;
        
        if ((assert_value = assert_next_token(fp, '}', 1, object))) {
            return assert_value;
        }

        if (i < monitoring_information->number_of_processes - 1) {
            if ((assert_value = assert_next_token(fp, ',', 1, object))) {
                return assert_value;
            }
            if ((assert_value = assert_next_token(fp, ' ', 1, object))) {
                return assert_value;
            }
        }
    }

    if ((assert_value = assert_next_token(fp, ']', 1, object))) {
        return assert_value;
    }

    // Users
    return_value = fscanf(fp, ", number_of_users=%d, users=[", &monitoring_information->number_of_users);
    if ((assert_value = assert_scanf_read_as_expected(return_value, 1, object))) {
        return consume_until_newline(fp);
    }
    num_read_arguments += return_value;

    monitoring_information->users = (struct user *) malloc(monitoring_information->number_of_users * sizeof(struct user));
    for (int i = 0; i < monitoring_information->number_of_users; i++) {
        if ((assert_value = assert_next_token(fp, '{', 1, object))) {
            return assert_value;
        }

        return_value = user_from_log(fp, monitoring_information->users + i);
        if ((assert_value = assert_scanf_read_as_expected(return_value, 0, object))) {
            return consume_until_newline(fp);
        }
        num_read_arguments += return_value;
        
        if ((assert_value = assert_next_token(fp, '}', 1, object))) {
            return assert_value;
        }

        if (i < monitoring_information->number_of_users - 1) {
            if ((assert_value = assert_next_token(fp, ',', 1, object))) {
                return assert_value;
            }
            if ((assert_value = assert_next_token(fp, ' ', 1, object))) {
                return assert_value;
            }
        }
    }

    if ((assert_value = assert_next_token(fp, ']', 1, object))) {
        return assert_value;
    }

    if ((assert_value = assert_next_token(fp, '}', 1, object))) {
        return assert_value;
    }

    if ((assert_value = assert_next_token(fp, '\n', 1, object))) {
        return assert_value;
    }

    return num_read_arguments;
}
