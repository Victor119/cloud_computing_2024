#include <stdlib.h>

#include "monitoring_information.h"


void free_monitoring_information(struct monitoring_information * monitoring_information) {
    free_system_information(monitoring_information->system_information);
    free(monitoring_information->system_information);

    for (int i = 0; i < monitoring_information->number_of_processes; i++) {
        free_process(monitoring_information->processes + i);
    }
    free(monitoring_information->processes);

    for (int i = 0; i < monitoring_information->number_of_users; i++) {
        free_user(monitoring_information->users + i);
    }
    free(monitoring_information->users);
}

void fetch_monitoring_information(time_t monitoring_time, struct monitoring_information *monitoring_information) {
    monitoring_information->monitoring_time = monitoring_time;
    fetch_system_information(&monitoring_information->system_information);
    list_processes(&monitoring_information->number_of_processes, &monitoring_information->processes);
    get_logged_in_users(&monitoring_information->number_of_users, &monitoring_information->users);
}
