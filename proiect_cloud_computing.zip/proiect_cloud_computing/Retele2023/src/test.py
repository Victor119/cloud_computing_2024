import socket
import re
import datetime as dt
import fcntl
import os
import errno
import time

def get_lines(sock: socket.socket, num_lines, last_buffer="", buffer_size=1024):
    lines = []
    buffer = last_buffer

    while len(lines) < num_lines:
        start = 0
        for match in re.finditer('\n', buffer):
            position = match.start()

            lines.append(buffer[start:position])
            start = position + 1

            if len(lines) == num_lines:
                break
        
        last_buffer = buffer[start:]

        if len(lines) < num_lines:
            try:
                buffer = sock.recv(buffer_size).decode()
            except socket.error as e:
                err = e.args[0]

                if err == errno.EAGAIN or err == errno.EWOULDBLOCK:
                    # No data available
                    break
                else:
                    # A real error occurred
                    raise

            buffer = last_buffer + buffer

    return lines, last_buffer


def login(sock: socket.socket, username: str, password: str):
    sock.sendall(f'login {username} {password}'.encode())
    time.sleep(1)
    response_lines, remaining_buffer = get_lines(sock, 1, "")

    assert len(response_lines) == 1
    assert remaining_buffer == ""

    return response_lines[0] == 'ok login'

def stat(sock: socket.socket, start: int, end: int):
    sock.sendall(f'stat {int(start)} {int(end)}'.encode())
    time.sleep(4)

    int_regex = '\d+'
    int_array = f'({int_regex}\s+)+'
    float_regex = '[-+]?(\d+([.,]\d*)?|[.,]\d+)([eE][-+]?\d+)?'
    float_array = f'({float_regex}\s+)+'

    lines, remaininig_buffer = get_lines(sock, 6, "")

    if len(lines) == 1:
        # Probably a stat error
        print(lines[0])
        exit(0)

    num_samples = int(re.match(f'Num Samples: ({int_regex})', lines[0]).groups()[0])
    monitoring_times = list(map(int, re.match(f'Time: ({int_array})', lines[1]).groups()[0].split()))
    memory_usage = list(map(int, re.match(f'Memory: ({int_array})', lines[2]).groups()[0].split()))
    cpu_loads = list(map(float, re.match(f'CPU Load: ({float_array})', lines[3]).groups()[0].split()))
    num_connected_users = list(map(int, re.match(f'Num Connected Users: ({int_array})', lines[4]).groups()[0].split()))
    num_users = int(re.match(f'Num Users: ({int_regex})', lines[5]).groups()[0])

    print('Num Samples:', num_samples)
    print('Monitoring Times:', monitoring_times)
    print('Memory Usage:', memory_usage)
    print('CPU Loads:', cpu_loads)
    print('Num Connected Users:', num_connected_users)
    print('Num Users:', num_users)

    users = {}
    for _ in range(num_users):
        lines, remaininig_buffer = get_lines(sock, 1, remaininig_buffer)
        line = lines[0]

        match = re.match(f'User ([a-zA-Z0-9]+) logged in: ({int_array})', line)

        username, connection_statues = match.groups()[:2]
        connection_statues = list(map(int, connection_statues.split()))
        users[username] = connection_statues

    print('Users: ')
    for username, values in users.items():
        print(f'User {username}:', values)

    lines, remaininig_buffer = get_lines(sock, 2, remaininig_buffer)
    num_running_processes = list(map(int, re.match(f'Num Running Processes: ({int_array})', lines[0]).groups()[0].split()))
    num_processes = int(re.match(f'Num Processes: ({int_regex})', lines[1]).groups()[0])

    print('Num Running Processes: ', num_running_processes)
    print('Num Processes: ', num_processes)

    processes = {}
    for _ in range(num_processes):
        lines, remaininig_buffer = get_lines(sock, 1, remaininig_buffer)
        line = lines[0]

        match = re.match(f'Process ([^\s]+) [(]pid ({int_regex})[)] connections: ({int_array})', line)
        process_name, process_pid, process_num_connections = match.groups()[:3]

        process_pid = int(process_pid)
        process_num_connections = list(map(int, process_num_connections.split()))
        processes[(process_name, process_pid)] = process_num_connections

    print('Processes: ')
    for (process_name, process_pid), values in processes.items():
        print(f'Process {process_name} (pid {process_pid}):', values)
        


def main():
    host, port = 'localhost', 8081

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.connect((host, port))
        fcntl.fcntl(sock, fcntl.F_SETFL, os.O_NONBLOCK)

        if login(sock, 'guest', 'guest'):
            now = dt.datetime.now()

            start, end = (now - dt.timedelta(minutes=2)).timestamp(), now.timestamp()
            stat(sock, start, end)

if __name__ == "__main__":
    main()
