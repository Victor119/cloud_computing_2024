#include <stdlib.h>
#include "user.h"

void free_user(struct user *user) {
    free(user->username);
    free(user->hostname);
    free(user->terminal_name_suffix);
    free(user->tty);
}