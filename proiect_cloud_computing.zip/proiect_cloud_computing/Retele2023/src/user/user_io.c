#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "user.h"
#include "../common_utils/common_utils.h"

int user_from_log(FILE *fp, struct user *user) {
    int num_read_arguments = 0;
    size_t username_length, hostname_length, terminal_name_suffix_length, tty_length;
    int assert_value, return_value;
    char object[] = "a user log";


    return_value = fscanf(
        fp,
        "username_len=%lu, hostname_len=%lu, terminal_name_suffix_len=%lu, tty_len=%lu, ",
        &username_length,
        &hostname_length,
        &terminal_name_suffix_length,
        &tty_length
    );

    if ((assert_value = assert_scanf_read_as_expected(return_value, 4, object))) {
        return consume_until_any(fp, "}\n");
    }
    num_read_arguments += return_value;

    user->username = (char *) malloc(username_length + 1);
    user->hostname = (char *) malloc(hostname_length + 1);
    user->terminal_name_suffix = (char *) malloc(terminal_name_suffix_length + 1);
    user->tty = (char *) malloc(tty_length + 1);

    return_value = fscanf(
        fp,
        "type=%hd, username=\"%[^\"]\", hostname=\"%[^\"]\", process_pid=%d, terminal_name_suffix=\"%[^\"]\", tty=\"%[^\"]\", "
        "session_id=%d, remote_address=\"%d.%d.%d.%d\", last_updated_at=%lu, process_termination_status=%hd, process_exit_status=%hd",
        &user->type,
        user->username,
        user->hostname,
        &user->process_pid,
        user->terminal_name_suffix,
        user->tty,
        &user->session_id,
        &user->remote_address[0], &user->remote_address[1], &user->remote_address[2], &user->remote_address[3],
        &user->last_updated_at,
        &user->process_termination_status,
        &user->process_exit_status
    );

    if ((assert_value = assert_scanf_read_as_expected(return_value, 14, object))) {
        return consume_until_any(fp, "}\n");
    }
    num_read_arguments += return_value;

    return num_read_arguments;
}

// Write the process information to a file
int user_log(FILE *fp, struct user *user) {
    return fprintf(
        fp,
        "username_len=%lu, hostname_len=%lu, terminal_name_suffix_len=%lu, tty_len=%lu, "
        "type=%hd, username=\"%s\", hostname=\"%s\", process_pid=%d, terminal_name_suffix=\"%s\", tty=\"%s\", "
        "session_id=%d, remote_address=\"%d.%d.%d.%d\", last_updated_at=%lu, process_termination_status=%hd, process_exit_status=%hd",
        strlen(user->username),
        strlen(user->hostname),
        strlen(user->terminal_name_suffix),
        strlen(user->tty),

        user->type,
        user->username,
        user->hostname,
        user->process_pid,
        user->terminal_name_suffix,
        user->tty,
        user->session_id,
        user->remote_address[0], user->remote_address[1], user->remote_address[2], user->remote_address[3],
        user->last_updated_at,
        user->process_termination_status,
        user->process_exit_status
    );
}
