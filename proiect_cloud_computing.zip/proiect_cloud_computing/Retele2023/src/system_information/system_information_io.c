#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "system_information.h"
#include "../common_utils/common_utils.h"


int system_information_from_log(FILE *fp, struct system_information *system_information) {
    int num_read_arguments = 0;
    size_t os_name_length, hostname_length, kernel_release_length, kernel_version_length, architecture_length;
    int return_value, assert_value;
    char object[] = "a system information log";

    return_value = fscanf(
        fp,
        "os_name_len=%lu, hostname_len=%lu, kernel_release_len=%lu, kernel_version_len=%lu, architecture_len=%lu, ",
        &os_name_length,
        &hostname_length,
        &kernel_release_length,
        &kernel_version_length,
        &architecture_length
    );

    if ((assert_value = assert_scanf_read_as_expected(return_value, 5, object))) {
        return consume_until_any(fp, "}\n");
    }
    num_read_arguments += return_value;

    system_information->os_name = (char *) malloc(os_name_length + 1);
    system_information->hostname = (char *) malloc(hostname_length + 1);
    system_information->kernel_release = (char *) malloc(kernel_release_length + 1);
    system_information->kernel_version = (char *) malloc(kernel_version_length + 1);
    system_information->architecture = (char *) malloc(architecture_length + 1);

    return_value = fscanf(
        fp,
        "os_name=\"%[^\"]\", hostname=\"%[^\"]\", kernel_release=\"%[^\"]\", kernel_version=\"%[^\"]\", architecture=\"%[^\"]\", "
        "uptime=%lu, total_ram=%lu, free_ram=%lu , shared_ram=%lu, buffer_ram=%lu, total_swap=%lu, free_ram=%lu, number_of_running_processes=%hu, "
        "last_minure_cpu_load_factor=%f, last_five_minutes_cpu_load_factor=%f, last_fifteen_minutes_cpu_load_factor=%f",
        system_information->os_name,
        system_information->hostname,
        system_information->kernel_release,
        system_information->kernel_version,
        system_information->architecture,

        &system_information->uptime,
        &system_information->total_ram,
        &system_information->free_ram,
        &system_information->shared_ram,
        &system_information->buffer_ram,
        &system_information->total_swap,
        &system_information->free_swap,
        &system_information->number_of_running_processes,
        &system_information->last_minute_cpu_load_factor,
        &system_information->last_five_minutes_cpu_load_factor,
        &system_information->last_fifteen_minutes_cpu_load_factor
    );

    if ((assert_value = assert_scanf_read_as_expected(return_value, 16, object))) {
        return consume_until_any(fp, "}\n");
    }
    num_read_arguments += return_value;

    return num_read_arguments;
}

int system_information_log(FILE *fp, struct system_information *system_information) {
    return fprintf(
        fp,
        "os_name_len=%lu, hostname_len=%lu, kernel_release_len=%lu, kernel_version_len=%lu, architecture_len=%lu, "
        "os_name=\"%s\", hostname=\"%s\", kernel_release=\"%s\", kernel_version=\"%s\", architecture=\"%s\", "
        "uptime=%lu, total_ram=%lu, free_ram=%lu, shared_ram=%lu, buffer_ram=%lu, total_swap=%lu, free_ram=%lu, number_of_running_processes=%hu, "
        "last_minure_cpu_load_factor=%f, last_five_minutes_cpu_load_factor=%f, last_fifteen_minutes_cpu_load_factor=%f",
        strlen(system_information->os_name),
        strlen(system_information->hostname),
        strlen(system_information->kernel_release),
        strlen(system_information->kernel_version),
        strlen(system_information->architecture),

        system_information->os_name,
        system_information->hostname,
        system_information->kernel_release,
        system_information->kernel_version,
        system_information->architecture,
        system_information->uptime,
        system_information->total_ram,
        system_information->free_ram,
        system_information->shared_ram,
        system_information->buffer_ram,
        system_information->total_swap,
        system_information->free_swap,
        system_information->number_of_running_processes,
        system_information->last_minute_cpu_load_factor,
        system_information->last_five_minutes_cpu_load_factor,
        system_information->last_fifteen_minutes_cpu_load_factor
    );
}
