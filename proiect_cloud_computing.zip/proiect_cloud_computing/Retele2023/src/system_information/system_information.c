#include <stdio.h>
#include <stdlib.h>
#include "../common_utils/common_utils.h"
#include "system_information.h"


void free_system_information(struct system_information *system_information) {
    free(system_information->os_name);
    free(system_information->hostname);
    free(system_information->kernel_release);
    free(system_information->kernel_version);
    free(system_information->architecture);
}