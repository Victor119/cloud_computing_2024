#include <sys/utsname.h>
#include <sys/sysinfo.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "system_information.h"

int fetch_system_information(struct system_information **system_information) {
    struct utsname uname_data;
    int return_value = uname(&uname_data);

    if (return_value > 0) {
        return EXIT_FAILURE;
    }

    struct sysinfo sysinfo_data;
    return_value = sysinfo(&sysinfo_data);

    if (return_value > 0) {
        return EXIT_FAILURE;
    }

    struct system_information *current_system_information = (struct system_information *) malloc(sizeof(struct system_information));

    current_system_information->os_name = strdup(uname_data.sysname);
    current_system_information->hostname = strdup(uname_data.nodename);
    current_system_information->kernel_release = strdup(uname_data.release);
    current_system_information->kernel_version = strdup(uname_data.version);
    current_system_information->architecture = strdup(uname_data.machine);

    current_system_information->uptime = sysinfo_data.uptime;
    current_system_information->total_ram = sysinfo_data.totalram * sysinfo_data.mem_unit;
    current_system_information->free_ram = sysinfo_data.freeram * sysinfo_data.mem_unit;
    current_system_information->shared_ram = sysinfo_data.sharedram * sysinfo_data.mem_unit;
    current_system_information->buffer_ram = sysinfo_data.bufferram * sysinfo_data.mem_unit;
    current_system_information->total_swap = sysinfo_data.totalswap * sysinfo_data.mem_unit;
    current_system_information->free_swap = sysinfo_data.freeswap * sysinfo_data.mem_unit;
    current_system_information->number_of_running_processes = sysinfo_data.procs;

    current_system_information->last_minute_cpu_load_factor = sysinfo_data.loads[0];
    current_system_information->last_five_minutes_cpu_load_factor = sysinfo_data.loads[1];
    current_system_information->last_fifteen_minutes_cpu_load_factor = sysinfo_data.loads[2];

    *system_information = current_system_information;

    return EXIT_SUCCESS;
}
