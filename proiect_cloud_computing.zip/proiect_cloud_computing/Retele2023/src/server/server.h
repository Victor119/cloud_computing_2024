# ifndef SERVER_H
# define SERVER_H

void* client_thread(void* arg);

int start_server(int port);

# endif // SERVER_H