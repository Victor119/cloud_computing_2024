#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>
#include <pthread.h>

#include "monitoring_information_thread.h"
#include "../../monitoring_information/monitoring_information.h"
#include "../operations/statistics/statistics.h"


int get_log_files(char *logs_metadata_file_name, int *num_log_files, time_t **monitoring_times) {
    FILE* logs_metadata_file = fopen(logs_metadata_file_name, "r");

    int count = 0, capacity = 1;
    time_t *current_monitoring_times = (time_t *) malloc(capacity * sizeof(time_t));

    if (logs_metadata_file == NULL) {
        *num_log_files = 0;
        *monitoring_times = NULL;
        return EXIT_SUCCESS;
    }

    int return_value;
    while ((return_value = fscanf(logs_metadata_file, LOGS_DIR"/%lu.log\n", &current_monitoring_times[count])) == 1) {
        count++;

        if (count == capacity) {
            capacity *= 2;
            current_monitoring_times = (time_t *) realloc(current_monitoring_times, capacity * sizeof(time_t));
        }
    }

    if (return_value != EOF) {
        perror("Error reading logs metadata file");
        free(current_monitoring_times);
        *num_log_files = 0;
        *monitoring_times = NULL;
        return EXIT_FAILURE;
    }

    if (count == 0) {
        free(current_monitoring_times);
        current_monitoring_times = NULL;
    } else if (count < capacity) {
        current_monitoring_times = (time_t *) realloc(current_monitoring_times, count * sizeof(time_t));
    }

    fclose(logs_metadata_file);

    *num_log_files = count;
    *monitoring_times = current_monitoring_times;

    return EXIT_SUCCESS;
}


void change_primary_log_file(FILE *logs_metadata_file, time_t monitoring_time, char **new_log_file_name) {
    int monitoring_time_length = floor(log10(monitoring_time)) + 1;

    *new_log_file_name = (char *) malloc((strlen(LOGS_DIR) + 6 + monitoring_time_length) * sizeof(char));
    sprintf(*new_log_file_name, "%s/%lu.log", LOGS_DIR, monitoring_time);

    printf("Rotating to new log file: %s\n", *new_log_file_name);
    fprintf(logs_metadata_file, "%s\n", *new_log_file_name);
    fflush(logs_metadata_file);
}

void set_primary_log_file(time_t monitoring_time, char **new_log_file_name) {
    int monitoring_time_length = floor(log10(monitoring_time)) + 1;

    *new_log_file_name = (char *) malloc((strlen(LOGS_DIR) + 6 + monitoring_time_length) * sizeof(char));
    sprintf(*new_log_file_name, "%s/%lu.log", LOGS_DIR, monitoring_time);

    printf("Appending to existing log file: %s\n", *new_log_file_name);
}


int append_file(const char *source_path, const char *destination_path) {
    FILE *source_file, *destination_file;
    char buffer[1024];
    size_t bytes_read;

    source_file = fopen(source_path, "r");
    if (source_file == NULL) {
        perror("Error opening source file");
        return EXIT_FAILURE;
    }

    destination_file = fopen(destination_path, "a");
    if (destination_file == NULL) {
        perror("Error opening destination file");
        return EXIT_FAILURE;
    }

    while ((bytes_read = fread(buffer, 1, sizeof(buffer), source_file)) > 0) {
        fwrite(buffer, 1, bytes_read, destination_file);
    }

    fflush(destination_file);

    fclose(source_file);
    fclose(destination_file);
}

void log_monitoring_information(char *log_file_name, char *mode, struct monitoring_information *monitoring_information) {
    FILE* log_file = fopen(log_file_name, mode);

    monitoring_information_log(log_file, monitoring_information);

    fclose(log_file);
}

static void ensure_directory_exists(const char *dir) {
    char tmp[256];
    char *p = NULL;
    size_t len;

    snprintf(tmp, sizeof(tmp),"%s",dir);
    len = strlen(tmp);
    if (tmp[len - 1] == '/')
        tmp[len - 1] = 0;
    for (p = tmp + 1; *p; p++)
        if (*p == '/') {
            *p = 0;
            mkdir(tmp, S_IRWXU);
            *p = '/';
        }
    mkdir(tmp, S_IRWXU);
}

time_t get_last_monitoring_time(char *log_file_name) {
    FILE *fp = fopen(log_file_name, "r");

    struct monitoring_information monitoring_information;
    time_t last_monitoring_time = 0;
    int return_value = 0;

    while (1 == 1) {
        if((return_value = monitoring_information_from_log(fp, &monitoring_information)) == EOF) {
            break;
        }

        last_monitoring_time = monitoring_information.monitoring_time;
        free_monitoring_information(&monitoring_information);
    }

    fclose(fp);

    return last_monitoring_time;
}

void* monitoring_information_thread(void *args) {
    int num_log_files;
    time_t *monitoring_times;

    ensure_directory_exists(LOGS_DIR);
    get_log_files(LOGS_DIR"/logs_metadata.txt", &num_log_files, &monitoring_times);

    FILE* log_files_metadata = fopen(LOGS_DIR"/logs_metadata.txt", "a");
    char* log_file_name = NULL;
    time_t last_monitoring_time = 0;

    time_t log_start_time = time(NULL);
    if (num_log_files > 0) {
        log_start_time = monitoring_times[num_log_files - 1];
        set_primary_log_file(log_start_time, &log_file_name);

        last_monitoring_time = get_last_monitoring_time(log_file_name);
    } else {
        change_primary_log_file(log_files_metadata, log_start_time, &log_file_name);
    }

    while (1 == 1) {
        time_t monitoring_time = time(NULL);

        if (difftime(monitoring_time, log_start_time) >= LOG_ROTATION_SECONDS) {
            log_start_time = monitoring_time;
            
            free(log_file_name);
            change_primary_log_file(log_files_metadata, monitoring_time, &log_file_name);
        }

        time_t elapsed_time = difftime(monitoring_time, last_monitoring_time);
        if (elapsed_time < STATISTICS_GATHERING_INTERVAL_SECONDS) {
            sleep(STATISTICS_GATHERING_INTERVAL_SECONDS - elapsed_time);
            continue;
        }

        struct monitoring_information monitoring_information;
        fetch_monitoring_information(monitoring_time, &monitoring_information);

        log_monitoring_information(TEMPORARY_LOG_FILE_NAME, "w", &monitoring_information);
        append_file(TEMPORARY_LOG_FILE_NAME, log_file_name);

        last_monitoring_time = monitoring_information.monitoring_time;
        free_monitoring_information(&monitoring_information);

        sleep(STATISTICS_GATHERING_INTERVAL_SECONDS);
    }

    pthread_exit(NULL);
}