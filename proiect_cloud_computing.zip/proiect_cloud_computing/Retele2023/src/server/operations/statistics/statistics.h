#ifndef STATISTICS_H
#define STATISTICS_H

#include <time.h>
#include "../../../monitoring_information/monitoring_information.h"

int read_monitoring_information_from_log_files(
    int num_log_files,
    time_t* monitoring_times,
    time_t start_time,
    time_t end_time,
    int *number_of_monitoring_logs,
    struct monitoring_information **monitoring_information
);

int write_statistics_matrix(FILE *fp, int num_monitoring_informations, struct monitoring_information *monitoring_informations);

int fetch_statistics(int socket_client, time_t start_time, time_t end_time);

#endif
