#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "../common_utils/common_utils.h"
#include "network_connection.h"


int network_connection_from_file(FILE *fp, struct network_connection *network_connection, char *protocol) {
    if (fp == NULL) {
        return EXIT_FAILURE;
    }

    int is_tcp = (strncmp(protocol, "tcp", 3) == 0);

    int return_value;
    if ((return_value = consume_white_space(fp)) == EOF) {
        return return_value;
    }

    if ((return_value = consume_string(fp, &network_connection->entry_no)) == EOF) {
        free(network_connection->entry_no);
        return return_value;
    }
    consume_white_space(fp);

    network_connection->protocol = strdup(protocol);
    consume_string(fp, &network_connection->local_address); consume_white_space(fp);
    consume_string(fp, &network_connection->remote_address); consume_white_space(fp);
    consume_static_string(fp, network_connection->connection_state); consume_white_space(fp);

    char *queues;
    consume_string(fp, &queues); consume_white_space(fp);
    network_connection->transmit_queue = (char *) malloc(sizeof(char) * (strlen(queues) + 1));
    network_connection->receive_queue = (char *) malloc(sizeof(char) * (strlen(queues) + 1));
    sscanf(queues, "%[^:]:%s", network_connection->transmit_queue, network_connection->receive_queue);
    network_connection->transmit_queue = (char *) realloc(network_connection->transmit_queue, strlen(network_connection->transmit_queue) + 1);
    network_connection->receive_queue = (char *) realloc(network_connection->receive_queue, strlen(network_connection->receive_queue) + 1);
    free(queues);
    
    char _;
    consume_int(fp, &network_connection->timer_active); consume_char(fp, &_);
    consume_int(fp, &network_connection->time_until_timer_expiration); consume_white_space(fp);
    consume_unsigned_long(fp, &network_connection->number_of_unrecovered_rto_timeouts); consume_white_space(fp);
    consume_unsigned_long(fp, &network_connection->uid); consume_white_space(fp);
    consume_unsigned_long(fp, &network_connection->number_of_unanswered_0_window_probes); consume_white_space(fp);
    consume_unsigned_long(fp, &network_connection->inode); consume_white_space(fp);
    consume_int(fp, &network_connection->socket_reference_count); consume_white_space(fp);
    consume_string(fp, &network_connection->socket_memory_address); consume_white_space(fp);

    if (is_tcp) {
        consume_unsigned_long(fp, &network_connection->retransmit_timeout);
    }
    else {
        consume_unsigned_long(fp, &network_connection->drops);
    }

    consume_until_newline(fp);
}

int list_network_connections(int pid, int* number_of_network_connections, struct network_connection **network_connections) {
    char _;
    int count = 0, capacity = 1000;
    struct network_connection* current_network_connections = (struct network_connection *) malloc(capacity * sizeof(struct network_connection));
    char file_name[100];
    FILE* network_connections_file;

    sprintf(file_name, "/proc/%d/net/tcp", pid);
    network_connections_file = fopen(file_name, "r");
    if (network_connections_file != NULL) {

        // Read the header line
        consume_until_newline(network_connections_file);

        while (1 == 1) {
            int return_value = network_connection_from_file(
                network_connections_file,
                current_network_connections + count,
                "tcp"
            );

            if (return_value == EOF) {
                break;
            }

            if (++count == capacity) {
                capacity *= 2;
                current_network_connections = (struct network_connection *) realloc(current_network_connections, capacity * sizeof(struct network_connection));
            }
        }

        fclose(network_connections_file);
    }

    sprintf(file_name, "/proc/%d/net/tcp6", pid);
    network_connections_file = fopen(file_name, "r");
    if (network_connections_file != NULL) {

        // Read the header line
        consume_until_newline(network_connections_file);

        while (1 == 1) {
            int return_value = network_connection_from_file(
                network_connections_file,
                current_network_connections + count,
                "tcp6"
            );

            if (return_value == EOF) {
                break;
            }

            if (++count == capacity) {
                capacity *= 2;
                current_network_connections = (struct network_connection *) realloc(current_network_connections, capacity * sizeof(struct network_connection));
            }
        }

        fclose(network_connections_file);
    }

    sprintf(file_name, "/proc/%d/net/udp", pid);
    network_connections_file = fopen(file_name, "r");
    if (network_connections_file != NULL) {
        // Read the header line
        consume_until_newline(network_connections_file);

        while (1 == 1) {
            int return_value = network_connection_from_file(
                network_connections_file,
                current_network_connections + count,
                "udp"
            );

            if (return_value == EOF) {
                break;
            }

            if (++count == capacity) {
                capacity *= 2;
                current_network_connections = (struct network_connection *) realloc(current_network_connections, capacity * sizeof(struct network_connection));
            }
        }

        fclose(network_connections_file);
    }

    sprintf(file_name, "/proc/%d/net/udp6", pid);
    network_connections_file = fopen(file_name, "r");
    if (network_connections_file != NULL) {
        // Read the header line
        consume_until_newline(network_connections_file);

        while (1 == 1) {
            int return_value = network_connection_from_file(
                network_connections_file,
                current_network_connections + count,
                "udp6"
            );

            if (return_value == EOF) {
                break;
            }

            if (++count == capacity) {
                capacity *= 2;
                current_network_connections = (struct network_connection *) realloc(current_network_connections, capacity * sizeof(struct network_connection));
            }
        }

        fclose(network_connections_file);
    }

    if (count == 0) {
        free(current_network_connections);
        current_network_connections = NULL;
    } else if (count < capacity) {
        current_network_connections = (struct network_connection *) realloc(current_network_connections, count * sizeof(struct network_connection));
    }

    *number_of_network_connections = count;
    *network_connections = current_network_connections;

    return EXIT_SUCCESS;
}
