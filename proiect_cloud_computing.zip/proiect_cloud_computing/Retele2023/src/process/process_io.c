#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "process.h"
#include "../common_utils/common_utils.h"
#include "../network_connection/network_connection.h"

int process_from_log(FILE *fp, struct process *process) {
    size_t name_length;
    int num_read_arguments = 0;
    int return_value, assert_value;
    char object[] = "a process log";

    return_value = fscanf(
        fp,
        "name_len=%lu, ",
        &name_length
    );

    if ((assert_value = assert_scanf_read_as_expected(return_value, 1, object))) {
        return consume_until_any(fp, "}\n");
    }
    num_read_arguments += return_value;

    process->name = (char *) malloc(name_length + 1);

    return_value = fscanf(
        fp,
        "pid=%d, name=\"%[^\"]\", state=%c, parent_pid=%d, process_group_id=%d, session_id=%d, tty_nr=%d, foreground_process_group_id=%d, "
        "flags=%u, minor_faults=%lu, children_minor_faults=%lu, major_faults=%lu, children_major_faults=%lu, "
        "user_time=%lu, system_time=%lu, children_user_time=%ld, children_system_time=%ld, priority=%ld, nice=%ld, num_threads=%ld, "
        "time_till_next_interrupt=%ld, start_time=%llu, virtual_memory=%lu, num_pages=%ld, max_bytes_num_pages=%lu",

        &process->pid, process->name, &process->state,
        &process->parent_pid, &process->process_group_id, &process->session_id, &process->tty_nr,
        &process->foreground_process_group_id,
        &process->flags,
        &process->minor_faults, &process->children_minor_faults, &process->major_faults, &process->children_major_faults,
        &process->user_time, &process->system_time, &process->children_user_time, &process->children_system_time,
        &process->priority, &process->nice, &process->num_threads,
        &process->time_till_next_interrupt,
        &process->start_time, &process->virtual_memory, &process->num_pages, &process->max_bytes_num_pages
    );

    if ((assert_value = assert_scanf_read_as_expected(return_value, 25, object))) {
        return consume_until_any(fp, "}\n");
    }
    num_read_arguments += return_value;

    return_value = fscanf(fp, ", number_of_network_connections=%d, network_connections=[", &process->number_of_network_connections);
    if ((assert_value = assert_scanf_read_as_expected(return_value, 1, object))) {
        return consume_until_any(fp, "}\n");
    }

    num_read_arguments += return_value;

    if (process->number_of_network_connections > 0) {
        process->network_connections = (struct network_connection *) malloc(process->number_of_network_connections * sizeof(struct network_connection));
        for (int i = 0; i < process->number_of_network_connections; i++) {
            if ((assert_value = assert_next_token(fp, '{', 1, object))) {
                return consume_until_any(fp, "}\n");
            }
            
            return_value = network_connection_from_log(fp, process->network_connections + i);
            if ((assert_value = assert_scanf_read_as_expected(return_value, 0, object))) {
                return consume_until_any(fp, "}\n");
            }
            num_read_arguments += return_value;
            
            if ((assert_value = assert_next_token(fp, '}', 1, object))) {
                return consume_until_any(fp, "}\n");
            }

            if (i < process->number_of_network_connections - 1) {
                if ((assert_value = assert_next_token(fp, ',', 1, object))) {
                    return consume_until_any(fp, "}\n");
                }
                if ((assert_value = assert_next_token(fp, ' ', 1, object))) {
                    return consume_until_any(fp, "}\n");
                }
            }
        }
    }
    else {
        process->network_connections = NULL;
    }

    if ((assert_value = assert_next_token(fp, ']', 1, object))) {
        return consume_until_any(fp, "}\n");
    }

    return num_read_arguments;
}

int process_log(FILE *fp, struct process *process) {
    int num_written_bytes = 0, return_value;

    return_value = fprintf(
        fp,
        "name_len=%lu, "
        "pid=%d, name=\"%s\", state=%c, parent_pid=%d, process_group_id=%d, session_id=%d, tty_nr=%d, foreground_process_group_id=%d, "
        "flags=%u, minor_faults=%lu, children_minor_faults=%lu, major_faults=%lu, children_major_faults=%lu, "
        "user_time=%lu, system_time=%lu, children_user_time=%ld, children_system_time=%ld, priority=%ld, nice=%ld, num_threads=%ld, "
        "time_till_next_interrupt=%ld, start_time=%llu, virtual_memory=%lu, num_pages=%ld, max_bytes_num_pages=%lu, ",
        strlen(process->name),

        process->pid, process->name, process->state,
        process->parent_pid, process->process_group_id, process->session_id, process->tty_nr,
        process->foreground_process_group_id,
        process->flags,
        process->minor_faults, process->children_minor_faults, process->major_faults, process->children_major_faults,
        process->user_time, process->system_time, process->children_user_time, process->children_system_time,
        process->priority, process->nice, process->num_threads,
        process->time_till_next_interrupt,
        process->start_time, process->virtual_memory, process->num_pages, process->max_bytes_num_pages
    );

    if (return_value < 0) {
        return return_value;
    }
    num_written_bytes += return_value;

    return_value = fprintf(fp, "number_of_network_connections=%d, network_connections=[", process->number_of_network_connections);

    if (return_value < 0) {
        return return_value;
    }
    num_written_bytes += return_value;

    for (int i = 0; i < process->number_of_network_connections; i++) {
        if ((return_value = fprintf(fp, "{")) < 0) {
            return return_value;
        }
        num_written_bytes += return_value;

        if ((return_value = network_connection_log(fp, process->network_connections + i)) < 0) {
            return return_value;
        }
        num_written_bytes += return_value;

        if ((return_value = fprintf(fp, "}")) < 0) {
            return return_value;
        }
        num_written_bytes += return_value;

        if (i < process->number_of_network_connections - 1) {
            if ((return_value = fprintf(fp, ", ")) < 0) {
                return return_value;
            }
            num_written_bytes += return_value;
        }
    }

    if ((return_value = fprintf(fp, "]")) < 0) {
        return return_value;
    }
    num_written_bytes += return_value;

    return num_written_bytes;
}
