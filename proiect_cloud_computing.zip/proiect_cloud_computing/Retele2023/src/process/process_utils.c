#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>

#include "process.h"
#include "../common_utils/common_utils.h"
#include "../network_connection/network_connection.h"


int process_from_file(FILE *fp, struct process *process) {
    if (fp == NULL) {
        return EXIT_FAILURE;
    }

    consume_int(fp, &process->pid); consume_white_space(fp);
    consume_string_format(fp, "(%[^)])", &process->name); consume_white_space(fp);
    consume_char(fp, &process->state); consume_white_space(fp);

    consume_int(fp, &process->parent_pid); consume_white_space(fp);
    consume_int(fp, &process->process_group_id); consume_white_space(fp);
    consume_int(fp, &process->session_id); consume_white_space(fp);
    consume_int(fp, &process->tty_nr); consume_white_space(fp);
    
    consume_int(fp, &process->foreground_process_group_id); consume_white_space(fp);

    consume_unsigned_int(fp, &process->flags); consume_white_space(fp);

    consume_unsigned_long(fp, &process->minor_faults); consume_white_space(fp);
    consume_unsigned_long(fp, &process->children_minor_faults); consume_white_space(fp);
    consume_unsigned_long(fp, &process->major_faults); consume_white_space(fp);
    consume_unsigned_long(fp, &process->children_major_faults); consume_white_space(fp);

    consume_unsigned_long(fp, &process->user_time); consume_white_space(fp);
    consume_unsigned_long(fp, &process->system_time); consume_white_space(fp);
    consume_long(fp, &process->children_user_time); consume_white_space(fp);
    consume_long(fp, &process->children_system_time); consume_white_space(fp);

    consume_long(fp, &process->priority); consume_white_space(fp);
    consume_long(fp, &process->nice); consume_white_space(fp);
    consume_long(fp, &process->num_threads); consume_white_space(fp);

    consume_long(fp, &process->time_till_next_interrupt); consume_white_space(fp);

    consume_unsigned_long_long(fp, &process->start_time); consume_white_space(fp);
    consume_unsigned_long(fp, &process->virtual_memory); consume_white_space(fp);
    consume_long(fp, &process->num_pages); consume_white_space(fp);
    consume_unsigned_long(fp, &process->max_bytes_num_pages); consume_white_space(fp);
}

int get_process_from_stat_file(char *process_stat_file, struct process* process) {
    FILE * fp = fopen(process_stat_file, "r");
    if (fp == NULL) {
        return EXIT_FAILURE;
    }

    process_from_file(fp, process);
    fclose(fp);

    list_network_connections(process->pid, &process->number_of_network_connections, &process->network_connections);

    return EXIT_SUCCESS;
}

int get_open_inodes(char *process_file_descriptors_dir, int *num_open_fds, unsigned long **inodes) {
    DIR *dir = opendir(process_file_descriptors_dir);

    if (dir == NULL) {
        *num_open_fds = 0;
        *inodes = NULL;
        return EXIT_FAILURE;
    }

    int count = 0, capacity = 1;
    unsigned long* current_inodes = (unsigned long *) malloc(capacity * sizeof(unsigned long));

    struct dirent *ent;
    while (ent = readdir(dir)) {
        char *next_char;
        long result = strtol(ent->d_name, &next_char, 10);

        if (next_char == ent->d_name || *next_char != '\0' || errno == ERANGE) {
            continue;
        }

        char file_path[300];
        snprintf(file_path, 300, "%s/%s", process_file_descriptors_dir, ent->d_name);

        struct stat buf;
        if (stat(file_path, &buf) != 0) {
            continue;
        }

        current_inodes[count] = buf.st_ino;

        if (++count == capacity) {
            capacity *= 2;
            current_inodes = (unsigned long *) realloc(current_inodes, capacity * sizeof(unsigned long));
        }
    }
    closedir(dir);

    if (count == 0) {
        free(current_inodes);
        current_inodes = NULL;
    } else if (count < capacity) {
        current_inodes = (unsigned long *) realloc(current_inodes, count * sizeof(unsigned long));
    }
    
    *num_open_fds = count;
    *inodes = current_inodes;

    return EXIT_SUCCESS;
}

void filter_network_connection(struct process *process, int num_open_fds, unsigned long *open_inodes) {
    int count = 0, capacity = 1;
    struct network_connection* current_network_connections = (struct network_connection *) malloc(capacity * sizeof(struct network_connection));

    for (int i = 0; i < process->number_of_network_connections; i++) {
        int found = 0;
        for (int j = 0; j < num_open_fds; j++) {
            if (process->network_connections[i].inode == open_inodes[j]) {
                found = 1;
                break;
            }
        }

        if (found) {
            current_network_connections[count] = process->network_connections[i];

            if (++count == capacity) {
                capacity *= 2;
                current_network_connections = (struct network_connection *) realloc(current_network_connections, capacity * sizeof(struct network_connection));
            }
        }
        else {
            free_network_connection(process->network_connections + i);
        }
    }

    if (count != process->number_of_network_connections) {
        if (count == 0) {
            free(current_network_connections);
            current_network_connections = NULL;
        } else if (count < capacity) {
            current_network_connections = (struct network_connection *) realloc(current_network_connections, count * sizeof(struct network_connection));
        }

        free(process->network_connections);

        process->number_of_network_connections = count;
        process->network_connections = current_network_connections;
    }
    else {
        free(current_network_connections);
    }
}

int list_processes(int* number_of_processes, struct process **processes) {
    DIR *dir = opendir("/proc");

    if (dir == NULL) {
        *number_of_processes = 0;
        *processes = NULL;
        return EXIT_FAILURE;
    }


    char file_name[300];
    struct dirent *ent;
    int count = 0, capacity = 1;
    struct process* current_processes = (struct process *) malloc(capacity * sizeof(struct process));

    while (ent = readdir(dir)) {
        char *next_char;
        long result = strtol(ent->d_name, &next_char, 10);

        if (next_char == ent->d_name || *next_char != '\0' || errno == ERANGE) {
            continue;
        }

        snprintf(file_name, 300, "/proc/%s/stat", ent->d_name);
        if (get_process_from_stat_file(file_name, current_processes + count) != EXIT_SUCCESS) {
            continue;
        }

        int num_fds;
        unsigned long *open_inodes;
        snprintf(file_name, 300, "/proc/%s/fd", ent->d_name);
        get_open_inodes(file_name, &num_fds, &open_inodes);
        filter_network_connection(current_processes + count, num_fds, open_inodes);
        if (num_fds > 0) {
            free(open_inodes);
        }

        if (++count == capacity) {
            capacity *= 2;
            current_processes = (struct process *) realloc(current_processes, capacity * sizeof(struct process));
        }
    }

    if (count == 0) {
        free(current_processes);
        current_processes = NULL;
    } else if (count < capacity) {
        current_processes = (struct process *) realloc(current_processes, count * sizeof(struct process));
    }
    
    closedir(dir);

    *number_of_processes = count;
    *processes = current_processes;

    return EXIT_SUCCESS;
}
