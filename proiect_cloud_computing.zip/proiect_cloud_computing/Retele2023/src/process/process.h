#ifndef PROCESS_H_INCLUDED
#define PROCESS_H_INCLUDED

struct process {
    int pid;

    // The name of the process
    char* name;

    // The state of the process
    char state;

    // The parent process id
    int parent_pid;

    // The process group id
    int process_group_id;
    
    // The session id
    int session_id;
    
    // The controlling terminal of the process
    int tty_nr;

    // The foreground process group of the controlling terminal of the process
    int foreground_process_group_id;

    // The kernel flags word of the process
    unsigned int flags;
    
    // The number of minor faults the process has made which have not required loading a memory page from disk
    unsigned long minor_faults;

    // The number of minor faults that the process's waited-for children have made
    unsigned long children_minor_faults;

    // The number of major faults the process has made which have required loading a memory page from disk
    unsigned long major_faults;

    // The number of major faults that the process's waited-for children have made
    unsigned long children_major_faults;

    // The user time of the process
    unsigned long user_time;

    // The system time of the process
    unsigned long system_time;

    // The user time of the process's waited-for children
    long children_user_time;

    // The system time of the process's waited-for children
    long children_system_time;

    // The priority of the process
    long priority;
    
    // The nice value of the process
    long nice;
    
    // The number of threads in this process
    long num_threads;

    // The time in jiffies before the next SIGALRM is sent to the process due to an interval timer.
    long time_till_next_interrupt;

    // The time the process started after system boot
    unsigned long long start_time;

    // Virtual memory size in bytes
    unsigned long virtual_memory;

    // Resident Set Size: number of pages the process has in real memory
    long num_pages;

    // Resident Set Size: number of pages the process has in real memory
    unsigned long max_bytes_num_pages;

    // Number of TCP and UDP connections
    int number_of_network_connections;

    // Network connections
    struct network_connection *network_connections;
};

// Process methods

// Read the process information from a log file
int process_from_log(FILE* fp, struct process *process);

// Write the process information to a log file
int process_log(FILE* fp, struct process *process);

// Release the memory allocated by the process
void free_process(struct process *process);


// float get_cpu_usage_percentage(struct process *process);

// float get_memory_usage_percentage(struct process *process);

// Static methods
int list_processes(int* number_of_processes, struct process **processes);

#endif // PROCESS_H_INCLUDED