#include "server/server.h"

int main() {
    start_server(8081);

    return 0;
}
