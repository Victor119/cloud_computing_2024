#ifndef LOCAL_SYSTEM_H_INCLUDED
#define LOCAL_SYSTEM_H_INCLUDED

#include <stdio.h>

struct system_information {
    // The name of the system (e.g. Linux)
    char* os_name;

    // The hostname of the system
    char* hostname;

    // The kernel release version
    char* kernel_release;

    // The exact version of the kernel release
    char* kernel_version;

    // The machine architecture (e.g. x86_64)
    char* architecture;

    // The total current uptime of the system in seconds
    unsigned long uptime;
    
    // The total amount of RAM in bytes
    unsigned long total_ram;

    // The amount of free RAM in bytes
    unsigned long free_ram;

    // The amount of shared RAM in bytes
    unsigned long shared_ram;

    // The amount of buffered RAM in bytes
    unsigned long buffer_ram;

    // The total amount of swap in bytes
    unsigned long total_swap;

    // The amount of free swap in bytes
    unsigned long free_swap;

    // The number of processes running on the system at the monitor time
    unsigned short number_of_running_processes;

    // The load average factor of the system for the last minute
    // Between 0 and 1: 0 means no load, 1 means exactly at capacity
    // More than 1: the system is overloaded and processes are waiting
    float last_minute_cpu_load_factor;

    // The load average factor of the system for the last five minutes
    // Between 0 and 1: 0 means no load, 1 means exactly at capacity
    // More than 1: the system is overloaded and processes are waiting
    float last_five_minutes_cpu_load_factor;

    // The load average factor of the system for the last fifteen minutes
    // Between 0 and 1: 0 means no load, 1 means exactly at capacity
    // More than 1: the system is overloaded and processes are waiting
    float last_fifteen_minutes_cpu_load_factor;
};

// System information methods

// Read the user information from log file
int system_information_from_log(FILE *fp, struct system_information *system_information);

// Write the user information to log file
int system_information_log(FILE *fp, struct system_information *system_information);

// Release the memory allocated by the system information
void free_system_information(struct system_information *system_information);

// System information utils

int fetch_system_information(struct system_information **system_information);

#endif // LOCAL_SYSTEM_H_INCLUDED