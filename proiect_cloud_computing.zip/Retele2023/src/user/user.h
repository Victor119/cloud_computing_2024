#ifndef USER_H_INCLUDED
#define USER_H_INCLUDED

#include <stdio.h>
#include <time.h>

struct user {
    // The type of the connected user
    short type;

    // The username of the user
    char* username;

    // The hostname where the user is logged in
    char *hostname;

    // The process id of the user's process
    int process_pid;

    // The terminal name suffix
    char* terminal_name_suffix;

    // The tty
    char *tty;

    // The session id of the windowing
    int session_id;

    // The last time the user was active
    time_t last_updated_at;

    // The remote address of the user
    int remote_address[4];

    // The process termination status
    short process_termination_status;

    // The process exit status
    short process_exit_status;
};

// User methods

// Read the user information from a log file
int user_from_log(FILE *fp, struct user *user);

// Write the user information to a log file
int user_log(FILE *fp, struct user *user);

// Release the memory allocated for the user
void free_user(struct user *user);

// User utils methods

int get_logged_in_users(int *number_of_users, struct user** users);

#endif // USER_H_INCLUDED
