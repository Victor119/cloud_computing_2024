#include <stdio.h>
#include <utmp.h>
#include <stdlib.h>
#include <string.h>

#include "user.h"

void fetch_user_from_utmp(struct utmp *utmp_user, struct user *user) {
    user->type = utmp_user->ut_type;

    user->username = (char *) malloc(sizeof utmp_user->ut_name);
    if (strlen(utmp_user->ut_user) == 0) {
        strncpy(utmp_user->ut_name, " \0", 2);
    }
    strncpy(user->username, utmp_user->ut_name, (int)(sizeof utmp_user->ut_name));

    user->hostname = (char *) malloc(sizeof utmp_user->ut_host);
    if (strlen(utmp_user->ut_host) == 0) {
        strncpy(utmp_user->ut_host, " \0", 2);
    }
    strncpy(user->hostname, utmp_user->ut_host, (int)(sizeof utmp_user->ut_host));

    user->process_pid = utmp_user->ut_pid;

    user->terminal_name_suffix = (char *) malloc(sizeof utmp_user->ut_line);
    if (strlen(utmp_user->ut_line) == 0) {
        strncpy(utmp_user->ut_line, " \0", 2);
    }
    strncpy(user->terminal_name_suffix, utmp_user->ut_line, (int)(sizeof utmp_user->ut_line));

    user->tty = (char *) malloc(sizeof utmp_user->ut_id);
    if (strlen(utmp_user->ut_id) == 0) {
        strncpy(utmp_user->ut_id, " \0", 2);
    }
    strncpy(user->tty, utmp_user->ut_id, (int)(sizeof utmp_user->ut_id));

    user->session_id = utmp_user->ut_session;
    
    memcpy(user->remote_address, utmp_user->ut_addr_v6, sizeof utmp_user->ut_addr_v6);

    user->last_updated_at = (time_t) utmp_user->ut_tv.tv_sec;

    user->process_termination_status = utmp_user->ut_exit.e_termination;
    user->process_exit_status = utmp_user->ut_exit.e_exit;
}

int get_logged_in_users(int *number_of_users, struct user** users) {
    FILE *ufp = fopen(_PATH_UTMP ,"r");
    if (ufp == NULL) {
        return EXIT_FAILURE;
    }

    struct utmp usr;
    int count = 0, capacity = 1;
    struct user *current_users = (struct user *) malloc(capacity * sizeof(struct user));

    while (fread((char *)&usr, sizeof(usr), 1, ufp) == 1) {
        if (*usr.ut_name && *usr.ut_line && *usr.ut_line != '~') {
            fetch_user_from_utmp(&usr, current_users + count);

            if (++count == capacity) {
                capacity *= 2;
                current_users = (struct user *) realloc(current_users, capacity * sizeof(struct user));
            }
        }
    }

    if (count == 0) {
        free(current_users);
        current_users = NULL;
    } else if (count < capacity) {
        current_users = (struct user *) realloc(current_users, count * sizeof(struct user));
    }

    *number_of_users = count;
    *users = current_users;

    return EXIT_SUCCESS;
}
