import socket
import re
import datetime as dt
import fcntl
import os
import errno
import time
import io
import sys
import requests
from contextlib import contextmanager
import json

def get_lines(sock: socket.socket, num_lines, last_buffer="", buffer_size=1024):
    lines = []
    buffer = last_buffer

    while len(lines) < num_lines:
        start = 0
        for match in re.finditer('\n', buffer):
            position = match.start()

            lines.append(buffer[start:position])
            start = position + 1

            if len(lines) == num_lines:
                break
        
        last_buffer = buffer[start:]

        if len(lines) < num_lines:
            try:
                buffer = sock.recv(buffer_size).decode()
            except socket.error as e:
                err = e.args[0]

                if err == errno.EAGAIN or err == errno.EWOULDBLOCK:
                    # No data available
                    break
                else:
                    # A real error occurred
                    raise

            buffer = last_buffer + buffer

    return lines, last_buffer


def login(sock: socket.socket, username: str, password: str):
    sock.sendall(f'login {username} {password}'.encode())
    time.sleep(1)
    response_lines, remaining_buffer = get_lines(sock, 1, "")

    assert len(response_lines) == 1
    assert remaining_buffer == ""

    return response_lines[0] == 'ok login'

def stat(output_buffer, sock: socket.socket, start: int, end: int):
    stat_output_buffer = output_buffer
    output_buffer = io.StringIO()

    sock.sendall(f'stat {int(start)} {int(end)}'.encode())
    time.sleep(4)

    int_regex = '\d+'
    int_array = f'({int_regex}\s+)+'
    float_regex = '[-+]?(\d+([.,]\d*)?|[.,]\d+)([eE][-+]?\d+)?'
    float_array = f'({float_regex}\s+)+'

    lines, remaininig_buffer = get_lines(sock, 6, "")

    if len(lines) == 1:
        # Probably a stat error
        print(lines[0])
        exit(0)


    num_samples = int(re.match(f'Num Samples: ({int_regex})', lines[0]).groups()[0])
    monitoring_times = list(map(int, re.match(f'Time: ({int_array})', lines[1]).groups()[0].split()))
    memory_usage = list(map(int, re.match(f'Memory: ({int_array})', lines[2]).groups()[0].split()))
    cpu_loads = list(map(float, re.match(f'CPU Load: ({float_array})', lines[3]).groups()[0].split()))
    num_connected_users = list(map(int, re.match(f'Num Connected Users: ({int_array})', lines[4]).groups()[0].split()))
    num_users = int(re.match(f'Num Users: ({int_regex})', lines[5]).groups()[0])

    output_object = {}
    output_object['num_samples'] = num_samples
    output_object['monitoring_times'] = monitoring_times
    output_object['memory_usage'] = memory_usage
    output_object['cpu_loads'] = cpu_loads
    output_object['num_connected_users'] = num_connected_users
    output_object['num_users'] = num_users

    log_data(output_buffer, 'Num Samples:', num_samples)
    log_data(output_buffer, 'Monitoring Times:', monitoring_times)
    log_data(output_buffer, 'Memory Usage:', memory_usage)
    log_data(output_buffer, 'CPU Loads:', cpu_loads)
    log_data(output_buffer, 'Num Connected Users:', num_connected_users)
    log_data(output_buffer, 'Num Users:', num_users)

    users = {}
    for _ in range(num_users):
        lines, remaininig_buffer = get_lines(sock, 1, remaininig_buffer)
        line = lines[0]

        match = re.match(f'User ([a-zA-Z0-9]+) logged in: ({int_array})', line)

        username, connection_statues = match.groups()[:2]
        connection_statues = list(map(int, connection_statues.split()))
        users[username] = connection_statues

    output_object['users'] = []
    log_data(output_buffer, 'Users: ')
    for username, values in users.items():
        output_object['users'].append({
            'username': username,
            'num_connections': values
        })
        log_data(output_buffer, f'User {username}:', values)

    lines, remaininig_buffer = get_lines(sock, 2, remaininig_buffer)
    num_running_processes = list(map(int, re.match(f'Num Running Processes: ({int_array})', lines[0]).groups()[0].split()))
    num_processes = int(re.match(f'Num Processes: ({int_regex})', lines[1]).groups()[0])

    output_object['num_running_processes'] = num_running_processes
    output_object['num_processes'] = num_processes
    log_data(output_buffer, 'Num Running Processes: ', num_running_processes)
    log_data(output_buffer, 'Num Processes: ', num_processes)

    processes = {}
    for _ in range(num_processes):
        lines, remaininig_buffer = get_lines(sock, 1, remaininig_buffer)
        line = lines[0]

        match = re.match(f'Process ([^\s]+) [(]pid ({int_regex})[)] connections: ({int_array})', line)
        process_name, process_pid, process_num_connections = match.groups()[:3]

        process_pid = int(process_pid)
        process_num_connections = list(map(int, process_num_connections.split()))
        processes[(process_name, process_pid)] = process_num_connections

    output_object['processes'] = []
    log_data(output_buffer, 'Processes: ')
    for (process_name, process_pid), values in processes.items():
        output_object['processes'].append({
            'process_name': process_name,
            'process_pid': process_pid,
            'num_connections': values
        })
        log_data(output_buffer, f'Process {process_name} (pid {process_pid}):', values)

    stat_output_buffer.write(json.dumps(output_object, indent=4))

@contextmanager
def capture_output():
    temporary_output = io.StringIO()

    previous_stdout, sys.stdout = sys.stdout, temporary_output
    yield temporary_output
    sys.stdout = previous_stdout


def log_data(output_buffer, *args, **kwargs):
    with capture_output() as printf_output:
        print(*args, **kwargs)

    printf_data = printf_output.getvalue()
    print(printf_data, end='')
    output_buffer.write(printf_data)


def get_function_key_from_vault():

    KEY_VAULT_NAME = 'reteleprojectkeys'
    SECRET_NAME = 'function-triggerstorage-key'

    from azure.keyvault.secrets import SecretClient
    from azure.identity import DefaultAzureCredential

    credential = DefaultAzureCredential(
        exclude_visual_studio_code_credential=False,
        exclude_interactive_browser_credential=False,
        additionally_allowed_tenants="*"
    )
    client = SecretClient(
        vault_url=f"https://{KEY_VAULT_NAME}.vault.azure.net",
        credential=credential
    )

    return client.get_secret(SECRET_NAME).value


def get_cached_function_key():
    current_folder = os.path.dirname(__file__)
    key_file = os.path.join(current_folder, '.function_key')

    if not os.path.exists(key_file):
        return None

    if not os.path.isfile(key_file):
        raise ValueError(
            f"The key file {key_file} is not a file! Please detele it")

    with open(key_file, 'rt') as reader:
        return reader.read().strip()


def cache_function_key(function_key):
    current_folder = os.path.dirname(__file__)
    key_file = os.path.join(current_folder, '.function_key')

    with open(key_file, 'wt') as writer:
        writer.write(function_key)


def upload(content):
    FUNCTION_APP = 'triggerstorage2'
    FUNCTION_NAME = 'upload'

    function_key = get_cached_function_key()
    if function_key is None:
        function_key = get_function_key_from_vault()
        cache_function_key(function_key)

    function_url = f'https://{FUNCTION_APP}.azurewebsites.net/api/{FUNCTION_NAME}?code={function_key}'

    return requests.post(function_url, data=content)


def main():
    host, port = 'localhost', 8081
    interval_minutes = 1

    while True:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.connect((host, port))
            fcntl.fcntl(sock, fcntl.F_SETFL, os.O_NONBLOCK)

            if login(sock, 'guest', 'guest'):
                now = dt.datetime.now()
                
                start, end = (now - dt.timedelta(minutes=interval_minutes)).timestamp(), now.timestamp()
                start_str = dt.datetime.fromtimestamp(start).strftime('%Y-%m-%d %H:%M:%S')
                end_str = dt.datetime.fromtimestamp(end).strftime('%Y-%m-%d %H:%M:%S')

                output_buffer = io.StringIO()
                stat(output_buffer, sock, start, end)

                response = upload(output_buffer.getvalue())
                print(f'Sent stats from {start_str} to {end_str}')
                print(f'Got reponse {response.status_code}: {response.text}')
            else:
                print('Failed to login')
                exit(0)
        
        time.sleep(60 * interval_minutes)
        print('Done sleeping!')


if __name__ == "__main__":
    main()
