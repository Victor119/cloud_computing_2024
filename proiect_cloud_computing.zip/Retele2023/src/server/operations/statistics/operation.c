#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "statistics.h"
#include "../../monitoring_information_thread/monitoring_information_thread.h"


int fetch_statistics(int socket_client, time_t start_time, time_t end_time) {
    int num_log_files;
    time_t *monitoring_times;

    int num_monitoring_informations;
    struct monitoring_information *monitoring_informations;

    get_log_files(LOGS_DIR"/logs_metadata.txt", &num_log_files, &monitoring_times);
    
    read_monitoring_information_from_log_files(
        num_log_files,
        monitoring_times,
        start_time,
        end_time,
        &num_monitoring_informations,
        &monitoring_informations
    );

    // Return
    FILE *fp = fdopen(socket_client, "w");
    write_statistics_matrix(fp, num_monitoring_informations, monitoring_informations);
    fclose(fp);
}
