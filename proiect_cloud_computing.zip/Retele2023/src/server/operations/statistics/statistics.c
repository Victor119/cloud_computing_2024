#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "statistics.h"
#include "../../monitoring_information_thread/monitoring_information_thread.h"
#include "../../../monitoring_information/monitoring_information.h"

int read_monitoring_information_from_log_files(
    int num_log_files,
    time_t* monitoring_times,
    time_t start_time,
    time_t end_time,
    int *number_of_monitoring_logs,
    struct monitoring_information **monitoring_information
) {
    int count = 0, capacity = 1;
    struct monitoring_information *current_monitoring_information = (struct monitoring_information *) malloc(capacity * sizeof(struct monitoring_information));

    for (int i = 0; i < num_log_files; i++) {
        char log_file_name[1024];
        sprintf(log_file_name, LOGS_DIR"/%lu.log", monitoring_times[i]);

        FILE *log_file = fopen(log_file_name, "r");
        if (log_file == NULL) {
            continue;
        }

        while (1 == 1) {
            int return_value = monitoring_information_from_log(log_file, current_monitoring_information + count);

            if (return_value == EOF) {
                break;
            }

            if (current_monitoring_information[count].monitoring_time < start_time || current_monitoring_information[count].monitoring_time > end_time) {
                free_monitoring_information(current_monitoring_information + count);
                continue;
            }

            count += 1;
            if (count == capacity) {
                capacity *= 2;
                current_monitoring_information = (struct monitoring_information *) realloc(current_monitoring_information, capacity * sizeof(struct monitoring_information));
            }
        }
    }

    if (count == 0) {
        free(current_monitoring_information);
        current_monitoring_information = NULL;
    } else if (count < capacity) {
        current_monitoring_information = (struct monitoring_information *) realloc(current_monitoring_information, count * sizeof(struct monitoring_information));
    }

    *number_of_monitoring_logs = count;
    *monitoring_information = current_monitoring_information;

    return EXIT_SUCCESS;
}

int write_statistics_matrix(FILE *fp, int num_monitoring_informations, struct monitoring_information *monitoring_informations) {
    fprintf(fp, "Num Samples: %d\n", num_monitoring_informations);
    if (num_monitoring_informations == 0) {
        return EXIT_SUCCESS;
    }

    fprintf(fp, "Time: ");
    for (int i = 0; i < num_monitoring_informations; i++) {
        fprintf(fp, "%lu ", monitoring_informations[i].monitoring_time);
    }
    fprintf(fp, "\n");

    fprintf(fp, "Memory: ");
    for (int i = 0; i < num_monitoring_informations; i++) {
        fprintf(fp, "%lu ", monitoring_informations[i].system_information->total_ram - monitoring_informations[i].system_information->free_ram);
    }
    fprintf(fp, "\n");

    fprintf(fp, "CPU Load: ");
    for (int i = 0; i < num_monitoring_informations; i++) {
        fprintf(fp, "%f ", monitoring_informations[i].system_information->last_minute_cpu_load_factor);
    }
    fprintf(fp, "\n");

    fprintf(fp, "Num Connected Users: ");
    for (int i = 0; i < num_monitoring_informations; i++) {
        fprintf(fp, "%d ", monitoring_informations[i].number_of_users);
    }
    fprintf(fp, "\n");

    int capacity;

    capacity = 1;
    int num_unique_users = 0;
    char **unique_users = (char **) malloc(capacity * sizeof(char *));

    for (int i = 0; i < num_monitoring_informations; i++) {
        for (int j = 0; j < monitoring_informations[i].number_of_users; j++) {
            int found = 0;
            for (int k = 0; k < num_unique_users; k++) {
                if (strcmp(unique_users[k], monitoring_informations[i].users[j].username) == 0) {
                    found = 1;
                    break;
                }
            }

            if (!found) {
                unique_users[num_unique_users] = monitoring_informations[i].users[j].username;
                num_unique_users += 1;

                if (num_unique_users == capacity) {
                    capacity *= 2;
                    unique_users = (char **) realloc(unique_users, capacity * sizeof(char *));
                }
            }
        }
    }

    fprintf(fp, "Num Users: %d\n", num_unique_users);
    for (int i = 0; i < num_unique_users; i++) {
        fprintf(fp, "User %s logged in: ", unique_users[i]);

        for (int j = 0; j < num_monitoring_informations; j++) {
            int found = 0;
            for (int k = 0; k < monitoring_informations[j].number_of_users; k++) {
                if (strcmp(unique_users[i], monitoring_informations[j].users[k].username) == 0) {
                    found += 1;
                }
            }

            fprintf(fp, "%d ", found);
        }

        fprintf(fp, "\n");
    }

    free(unique_users);

    fprintf(fp, "Num Running Processes: ");
    for (int i = 0; i < num_monitoring_informations; i++) {
        fprintf(fp, "%d ", monitoring_informations[i].system_information->number_of_running_processes);
    }
    fprintf(fp, "\n");

    capacity = 1;
    int num_unique_processes = 0;
    char **unique_processes_names = (char **) malloc(capacity * sizeof(char *));
    int *unique_processes_pids = (int *) malloc(capacity * sizeof(int));

    for (int i = 0; i < num_monitoring_informations; i++) {
        for (int j = 0; j < monitoring_informations[i].number_of_processes; j++) {
            int found = 0;
            for (int k = 0; k < num_unique_processes; k++) {
                if ((strcmp(unique_processes_names[k], monitoring_informations[i].processes[j].name) == 0)
                    && unique_processes_pids[k] == monitoring_informations[i].processes[j].pid) {
                    found = 1;
                    break;
                }
            }

            if (!found) {
                unique_processes_names[num_unique_processes] = monitoring_informations[i].processes[j].name;
                unique_processes_pids[num_unique_processes] = monitoring_informations[i].processes[j].pid;
                num_unique_processes += 1;

                if (num_unique_processes == capacity) {
                    capacity *= 2;
                    unique_processes_names = (char **) realloc(unique_processes_names, capacity * sizeof(char *));
                    unique_processes_pids = (int *) realloc(unique_processes_pids, capacity * sizeof(int));
                }
            }
        }
    }

    fprintf(fp, "Num Processes: %d\n", num_unique_processes);
    for (int i = 0; i < num_unique_processes; i++) {
        fprintf(fp, "Process %s (pid %d) connections: ", unique_processes_names[i], unique_processes_pids[i]);

        for (int j = 0; j < num_monitoring_informations; j++) {
            int found = -1;
            for (int k = 0; k < monitoring_informations[j].number_of_processes; k++) {
                if ((strcmp(unique_processes_names[i], monitoring_informations[j].processes[k].name) == 0)
                    && unique_processes_pids[i] == monitoring_informations[j].processes[k].pid) {
                    found = k;
                    break;
                }
            }

            if (found >= 0) {
                fprintf(fp, "%d ", monitoring_informations[j].processes[found].number_of_network_connections);
            } else {
                fprintf(fp, "0 ");
            }
        }

        fprintf(fp, "\n");
    }

    free(unique_processes_names);
    free(unique_processes_pids);
}
