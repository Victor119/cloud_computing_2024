#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>


#include "server.h"
#include "monitoring_information_thread/monitoring_information_thread.h"


int start_server(int port) {
    int server_socket = socket(AF_INET, SOCK_STREAM, 0);
    
    if (server_socket == -1) {
        perror("socket");
        exit(EXIT_FAILURE);
    }
    
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        perror("bind");
        close(server_socket);
        exit(EXIT_FAILURE);
    }
    
    if (listen(server_socket, 5) == -1) {
        perror("listen");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    // Create monitoring thread
    pthread_t monitoring_thread;
    if (pthread_create(&monitoring_thread, NULL, monitoring_information_thread, NULL) != 0) {
        perror("Failed to create the monitoring thread");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    // Ignore broken pipe
    signal(SIGPIPE, SIG_IGN);

    while (1) {
        printf("Waiting for client connection...\n");

        struct sockaddr_in client_addr;
        socklen_t addr_len = sizeof(client_addr);

        int socket_client = accept(server_socket, (struct sockaddr*)&client_addr, &addr_len);
        if (socket_client == -1) {
            perror("Failed to accept connection");
            close(socket_client);
            exit(EXIT_FAILURE);
        }
        printf("Accepted connection from %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

        // Create new client thread
        pthread_t thread;
        if (pthread_create(&thread, NULL, client_thread, &socket_client) != 0) {
            perror("Failed to create new thread for client");
            close(socket_client);
        }
    }
    
    close(server_socket);

    return 0;
}