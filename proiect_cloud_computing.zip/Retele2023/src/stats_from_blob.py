import seaborn as sb
import pandas as pd
import matplotlib.pyplot as plt
import io

def load_files(parquet_directory):
    STORAGE_ACCOUNT_NAME = 'blobcontainer2'
    CONTAINER_NAME = 'tema4cc'

    from azure.storage.blob import BlobServiceClient
    from azure.identity import DefaultAzureCredential

    # credential = DefaultAzureCredential(
    #     exclude_visual_studio_code_credential=False,
    #     exclude_interactive_browser_credential=False,
    #     additionally_allowed_tenants="*"
    # )
    sas_token = '?sv=2023-01-03&st=2024-05-26T18%3A41%3A31Z&se=2025-06-27T18%3A41%3A00Z&sr=c&sp=rl&sig=eaRvsO91dkAiNrTXFNZhbpLc8HO2krr2yNn80FSWVyI%3D'
    client = BlobServiceClient(
        account_url=f"https://{STORAGE_ACCOUNT_NAME}.blob.core.windows.net",
        credential=sas_token
    )
    # client = BlobServiceClient(
    #     account_url=f"https://{STORAGE_ACCOUNT_NAME}.blob.core.windows.net",
    #     credential=credential
    # )
    container_client = client.get_container_client(CONTAINER_NAME)

    dataframes = []
    for blob in container_client.walk_blobs(name_starts_with=parquet_directory, delimiter=''):
        if not blob.name.endswith('parquet'):
            continue
            
        stream = io.BytesIO()
        container_client.get_blob_client(blob.name).download_blob().readinto(stream)
        stream.seek(0)

        dataframes.append(pd.read_parquet(stream))
    
    return pd.concat(dataframes, ignore_index=True)

df = load_files('processed')

# df = pd.read_parquet(
#     'https://blobcontainer2.blob.core.windows.net/tema4cc/processed/part-00000-94991b70-21e8-4e43-aa67-190ae259b78f-c000.snappy.parquet'
#     '?sv=2023-01-03&st=2024-05-26T18%3A41%3A31Z&se=2025-06-27T18%3A41%3A00Z&sr=c&sp=rl&sig=eaRvsO91dkAiNrTXFNZhbpLc8HO2krr2yNn80FSWVyI%3D'
# )
# df['monitoring_time'] = df['monitoring_time'].dt.strftime('%H:%M:%S')
df['monitoring_time'] = pd.to_datetime(df['monitoring_time'], unit='ms')

sb.lineplot(data=df, x='monitoring_time', y='num_running_processes')
plt.xticks(rotation=45)
plt.show()

