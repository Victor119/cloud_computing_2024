#ifndef COMMON_UTILS_H_INCLUDED
#define COMMON_UTILS_H_INCLUDED

#define SCANF_ERROR -2

int consume_long_long(FILE *fp, long long *value);
int consume_unsigned_long_long(FILE *fp, unsigned long long *value);
int consume_long(FILE *fp, long *value);
int consume_unsigned_long(FILE *fp, unsigned long *value);
int consume_int(FILE *fp, int *value);
int consume_unsigned_int(FILE *fp, unsigned int *value);
int consume_short(FILE *fp, short *value);
int consume_unsigned_short(FILE *fp, unsigned short *value);
int consume_char(FILE *fp, char *value);
int consume_string(FILE *fp, char **value);
int consume_string_format(FILE *fp, char *format, char **value);
int consume_static_string(FILE *fp, char *value);
int consume_static_string_format(FILE *fp, char *format, char *value);
int consume_float(FILE *fp, float *value);
int consume_double(FILE *fp, double *value);
int consume_white_space(FILE *fp);
int consume_until_newline(FILE *fp);
int consume_until(FILE *fp, char token);
int consume_until_any(FILE *fp, char *tokens);
int assert_scanf_read_as_expected(int scanf_return_value, int expected_number_of_arguments, char *object_that_is_parsed);
int assert_next_token(FILE *fp, char expected_token, int allow_eof, char *object_that_is_parsed);

#endif // TEST_H_INCLUDED