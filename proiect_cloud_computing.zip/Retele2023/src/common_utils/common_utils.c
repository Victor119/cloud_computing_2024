#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "common_utils.h"


int consume_long_long(FILE *fp, long long *value) {
    return fscanf(fp, "%lld", value);
}

int consume_unsigned_long_long(FILE *fp, unsigned long long *value) {
    return fscanf(fp, "%llu", value);
}

int consume_long(FILE *fp, long *value) {
    return fscanf(fp, "%ld", value);
}

int consume_unsigned_long(FILE *fp, unsigned long *value) {
    return fscanf(fp, "%lu", value);
}

int consume_int(FILE *fp, int *value) {
    return fscanf(fp, "%d", value);
}

int consume_unsigned_int(FILE *fp, unsigned int *value) {
    return fscanf(fp, "%ud", value);
}

int consume_short(FILE *fp, short *value) {
    return fscanf(fp, "%hd", value);
}

int consume_unsigned_short(FILE *fp, unsigned short *value) {
    return fscanf(fp, "%hu", value);
}

int consume_char(FILE *fp, char *value) {
    return fscanf(fp, "%c", value);
}

int consume_float(FILE *fp, float *value) {
    return fscanf(fp, "%f", value);
}

int consume_double(FILE *fp, double *value) {
    return fscanf(fp, "%lf", value);
}

int consume_string(FILE *fp, char **value) {
    long size = 0, capacity = 1;
    char *result = (char *) malloc(capacity);
    char c;
    int return_value;

    while ((return_value = fscanf(fp, "%c", &c)) != EOF) {
        result[size] = c;

        if (isspace(result[size])) {
            break;
        }

        size++;

        if (size == capacity) {
            capacity *= 2;
            result = (char*) realloc(result, capacity);
        }
    }

    result[size] = '\0';
    result = (char*) realloc(result, size + 1);

    (*value) = result;

    return return_value;
}

int consume_string_format(FILE *fp, char *format, char **value) {
    int return_value = consume_string(fp, value);

    if (return_value == EOF) {
        return return_value;
    }

    char *value_after_format = (char *) malloc(strlen(*value) + 1);
    return_value = sscanf(*value, format, value_after_format);
    value_after_format = (char *) realloc(value_after_format, strlen(value_after_format) + 1);

    *value = value_after_format;

    return return_value;
}

int consume_static_string(FILE *fp, char *value) {
    return fscanf(fp, "%s", value);
}

int consume_static_string_format(FILE *fp, char *format, char *value) {
    return fscanf(fp, format, &value);
}

int consume_white_space(FILE *fp) {
    int return_value;
    char c;

    while ((return_value = fscanf(fp, "%c", &c)) != EOF) {
        if (!isspace(c)) {
            fseek(fp, -1, SEEK_CUR);
            break;
        }
    }

    if (return_value == EOF) {
        return return_value;
    }

    return EXIT_SUCCESS;
}

int consume_until_newline(FILE *fp) {
    return consume_until(fp, '\n');
}

int consume_until(FILE *fp, char token) {
    char _;
    int n_characters = 0;

    while ((_ = fgetc(fp)) != EOF && _ != token) {
        n_characters++;
    }

    if (_ == EOF && n_characters == 0) {
        return EOF;
    }

    return n_characters;
}

int consume_until_any(FILE *fp, char *tokens) {
    char _;
    int n_characters = 0;

    while ((_ = fgetc(fp)) != EOF && strchr(tokens, _) != NULL) {
        n_characters++;
    }

    if (_ == EOF && n_characters == 0) {
        return EOF;
    }

    return n_characters;
}

int assert_scanf_read_as_expected(int scanf_return_value, int expected_number_of_arguments, char *object_that_is_parsed) {
    if (scanf_return_value == EOF) {
        fprintf(stderr, "Unexpected end of file while reading a process log");

        return EOF;
    } else if (expected_number_of_arguments > 0 && scanf_return_value != expected_number_of_arguments) {
        fprintf(
            stderr,
            "Expected to read %d items, but only read %d while parsing %s. "
            "This may indicate a formatting issue at write time.",
            expected_number_of_arguments,
            scanf_return_value,
            object_that_is_parsed
        );

        return SCANF_ERROR;
    }

    return 0;
}

int assert_next_token(FILE *fp, char expected_token, int allow_eof, char *object_that_is_parsed) {
    char _;
    int return_value = fscanf(fp, "%c", &_);
    if (return_value == EOF) {
        if (allow_eof) {
            return EOF;
        }
        fprintf(stderr, "Expected token '{' at the start of %s, but reached the end of the file", object_that_is_parsed);
        return EOF;
    } else if (_ != expected_token) {
        fprintf(stderr, "Expected token '{' at the start of %s, but found '%c'!", object_that_is_parsed, _);
        return SCANF_ERROR;
    }

    return 0;
}