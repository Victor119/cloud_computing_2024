#ifndef NETWORK_CONNECTION_H
#define NETWORK_CONNECTION_H

#include <stdio.h>

struct network_connection {
    char *entry_no;

    char *protocol;

    char *local_address, *remote_address;

    char connection_state[2];

    char *transmit_queue, *receive_queue;

    int timer_active, time_until_timer_expiration;

    unsigned long number_of_unrecovered_rto_timeouts;

    unsigned long uid;

    unsigned long number_of_unanswered_0_window_probes;

    unsigned long inode;

    int socket_reference_count;

    char* socket_memory_address;

    unsigned long retransmit_timeout;
    unsigned long drops;
};

// Network connection functions

// Read the network connection from log file
int network_connection_from_log(FILE *fp, struct network_connection *network_connection);

// Write the network connection to log file
int network_connection_log(FILE *fp, struct network_connection *network_connection);

// Release the memory of the network connection
void free_network_connection(struct network_connection *network_connection);


// Network connection utils

int list_network_connections(int pid, int* number_of_network_connections, struct network_connection **network_connections);

#endif // NETWORK_CONNECTION_H