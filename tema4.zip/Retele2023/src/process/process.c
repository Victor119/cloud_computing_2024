#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "process.h"
#include "../common_utils/common_utils.h"
#include "../network_connection/network_connection.h"


void free_process(struct process *process) {
    free(process->name);

    for(int i = 0; i < process->number_of_network_connections; i++) {
        free_network_connection(process->network_connections + i);
    }
    
    if (process->network_connections != NULL) {
        free(process->network_connections);
    }
}



// unsigned long get_uptime() {
//     struct sysinfo info;
//     sysinfo(&info);

//     return info.uptime / sysconf(_SC_CLK_TCK);
// }

// float get_cpu_usage_percentage(struct process *process_stat) {
//     unsigned long total_time = process_stat->user_time + process_stat->system_time;
//     total_time += process_stat->children_user_time + process_stat->children_system_time;

//     unsigned long total_time_seconds = total_time / sysconf(_SC_CLK_TCK);
//     unsigned long start_time = (process_stat->start_time / sysconf(_SC_CLK_TCK));

//     unsigned long elapsed_time_since_start = get_uptime() - start_time;

//     return 100 * (float) total_time_seconds / elapsed_time_since_start;
// }

// float get_memory_usage_percentage(struct process *process_stat) {
//     struct sysinfo info;
//     sysinfo(&info);

//     struct utsname system_info;
//     uname(&system_info);

//     unsigned long total_memory = info.totalram;
//     // total_memory += info.totalswap;
//     total_memory *= info.mem_unit;

//     unsigned long ram_usage = process_stat->num_pages * sysconf(_SC_PAGESIZE);
//     unsigned long process_memory = ram_usage;

//     return 100 * (float) process_memory / total_memory;
// }
