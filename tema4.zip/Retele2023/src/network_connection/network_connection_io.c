#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "network_connection.h"
#include "../common_utils/common_utils.h"


int network_connection_from_log(FILE *fp, struct network_connection *network_connection) {
    int num_read_arguments = 0;
    size_t protocol_length, entry_no_length, local_address_length, remote_address_length, transmit_queue_length, receive_queue_length, socket_memory_address_length;
    int assert_value, return_value;
    char object[] = "a network connection log";

    return_value = fscanf(
        fp,
        "protocol_len=%lu, entry_no_len=%lu, local_address_len=%lu, remote_address_len=%lu, transmit_queue_len=%lu, receive_queue_len=%lu, socket_memory_address_len=%lu, ",
        &protocol_length,
        &entry_no_length,
        &local_address_length,
        &remote_address_length,
        &transmit_queue_length,
        &receive_queue_length,
        &socket_memory_address_length
    );

    if ((assert_value = assert_scanf_read_as_expected(return_value, 7, object))) {
        return consume_until_any(fp, "}\n");
    }
    num_read_arguments += return_value;

    network_connection->protocol = (char *) malloc((protocol_length + 1) * sizeof(char));
    network_connection->entry_no = (char *) malloc((entry_no_length + 1) * sizeof(char));
    network_connection->local_address = (char *) malloc((local_address_length + 1) * sizeof(char));
    network_connection->remote_address = (char *) malloc((remote_address_length + 1) * sizeof(char));
    network_connection->transmit_queue = (char *) malloc((transmit_queue_length + 1) * sizeof(char));
    network_connection->receive_queue = (char *) malloc((receive_queue_length + 1) * sizeof(char));
    network_connection->socket_memory_address = (char *) malloc((socket_memory_address_length + 1) * sizeof(char));

    return_value = fscanf(
        fp,
        "protocol=\"%[^\"]\", entry_no=\"%[^\"]\", local_address=\"%[^\"]\", remote_address=\"%[^\"]\", connection_state=\"%[^\"]\", "
        "transmit_queue=\"%[^\"]\", receive_queue=\"%[^\"]\", timer_active=%d, time_until_timer_expiration=%d, "
        "number_of_unrecovered_rto_timeouts=%lu, uid=%lu, number_of_unanswered_0_window_probes=%lu, inode=%lu, "
        "socket_reference_count=%d, socket_memory_address=\"%[^\"]\", retransmit_timeout=%lu, drops=%lu",

        network_connection->protocol, network_connection->entry_no, network_connection->local_address, network_connection->remote_address, network_connection->connection_state,
        network_connection->transmit_queue, network_connection->receive_queue, &network_connection->timer_active, &network_connection->time_until_timer_expiration,
        &network_connection->number_of_unrecovered_rto_timeouts, &network_connection->uid, &network_connection->number_of_unanswered_0_window_probes, &network_connection->inode,
        &network_connection->socket_reference_count, network_connection->socket_memory_address, &network_connection->retransmit_timeout, &network_connection->drops
    );

    if ((assert_value = assert_scanf_read_as_expected(return_value, 17, object))) {
        return consume_until_any(fp, "}\n");
    }
    num_read_arguments += return_value;

    return num_read_arguments;
}

int network_connection_log(FILE *fp, struct network_connection *network_connection) {
    return fprintf(
        fp,
        "protocol_len=%lu, entry_no_len=%lu, local_address_len=%lu, remote_address_len=%lu, transmit_queue_len=%lu, receive_queue_len=%lu, socket_memory_address_len=%lu, "
        "protocol=\"%s\", entry_no=\"%s\", local_address=\"%s\", remote_address=\"%s\", connection_state=\"%s\", "
        "transmit_queue=\"%s\", receive_queue=\"%s\", timer_active=%d, time_until_timer_expiration=%d, "
        "number_of_unrecovered_rto_timeouts=%lu, uid=%lu, number_of_unanswered_0_window_probes=%lu, inode=%lu, "
        "socket_reference_count=%d, socket_memory_address=\"%s\", retransmit_timeout=%lu, drops=%lu",
        strlen(network_connection->protocol),
        strlen(network_connection->entry_no),
        strlen(network_connection->local_address),
        strlen(network_connection->remote_address),
        strlen(network_connection->transmit_queue),
        strlen(network_connection->receive_queue),
        strlen(network_connection->socket_memory_address),

        network_connection->protocol, network_connection->entry_no, network_connection->local_address, network_connection->remote_address, network_connection->connection_state,
        network_connection->transmit_queue, network_connection->receive_queue, network_connection->timer_active, network_connection->time_until_timer_expiration,
        network_connection->number_of_unrecovered_rto_timeouts, network_connection->uid, network_connection->number_of_unanswered_0_window_probes, network_connection->inode,
        network_connection->socket_reference_count, network_connection->socket_memory_address, network_connection->retransmit_timeout, network_connection->drops
    );
}
