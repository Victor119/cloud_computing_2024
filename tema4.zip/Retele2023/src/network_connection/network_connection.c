#include <stdlib.h>

#include "network_connection.h"

void free_network_connection(struct network_connection *network_connection) {
    free(network_connection->local_address);
    free(network_connection->entry_no);
    free(network_connection->protocol);
    free(network_connection->remote_address);
    free(network_connection->transmit_queue);
    free(network_connection->receive_queue);
    free(network_connection->socket_memory_address);
}
