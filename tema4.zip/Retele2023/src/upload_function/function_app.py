import azure.functions as func
import datetime as dt
import logging
import os
import datetime as dt

from azure.storage.blob import BlobServiceClient

app = func.FunctionApp()

STORAGE_ACCOUNT_NAME = 'blobcontainer2'
CONTAINER_NAME = 'tema4cc'


@app.function_name(name="upload")
@app.route(route="upload", auth_level=func.AuthLevel.FUNCTION, methods=("post",))
def test_function(req: func.HttpRequest) -> func.HttpResponse:
    logger = logging.getLogger(__name__)

    content = req.get_body()

    logger.debug(f'Received upload request with {content}')

    try:
        storage_account_key = os.environ["STORAGE_ACCOUNT_KEY"]
    except Exception as exception:
        return func.HttpResponse(
            "Failed to acquire storage account access key using the "
            f"STORAGE_ACCOUNT_KEY environment variable",
            status_code=500
        )

    try:
        sa_client = BlobServiceClient(
            f'https://{STORAGE_ACCOUNT_NAME}.blob.core.windows.net',
            credential={
                "account_name": STORAGE_ACCOUNT_NAME,
                "account_key": storage_account_key
            }
        )
    except Exception as exception:
        return func.HttpResponse(
            "Failed to acquire credentials or connect to the storage account "
            f"with exception {exception}",
            status_code=500
        )

    ts = dt.datetime.now()

    try:
        sa_blob_client = sa_client.get_blob_client(
            container=CONTAINER_NAME,
            blob=f'upload/year={ts.year}/month={ts.month}/day={ts.day}/{ts.strftime("%H_%M_%S_%f")}'
        )
        sa_blob_client.upload_blob(content)
    except Exception as exception:
        return func.HttpResponse(
            "Failed to acquire credentials or connect to the storage account "
            f"with exception {exception}",
            status_code=500
        )
    return func.HttpResponse(
        "Blob uploaded succesfully",
        status_code=200
    )
