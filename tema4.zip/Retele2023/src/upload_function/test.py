import requests
import os


def get_function_key_from_vault():

    KEY_VAULT_NAME = 'reteleprojectkeys'
    SECRET_NAME = 'function-triggerstorage-key'

    from azure.keyvault.secrets import SecretClient
    from azure.identity import DefaultAzureCredential

    credential = DefaultAzureCredential(
        exclude_visual_studio_code_credential=False,
        exclude_interactive_browser_credential=False,
        additionally_allowed_tenants="*"
    )
    client = SecretClient(
        vault_url=f"https://{KEY_VAULT_NAME}.vault.azure.net",
        credential=credential
    )

    return client.get_secret(SECRET_NAME).value


def get_cached_function_key():
    current_folder = os.path.dirname(__file__)
    key_file = os.path.join(current_folder, '.function_key')

    if not os.path.exists(key_file):
        return None

    if not os.path.isfile(key_file):
        raise ValueError(
            f"The key file {key_file} is not a file! Please detele it")

    with open(key_file, 'rt') as reader:
        return reader.read().strip()


def cache_function_key(function_key):
    current_folder = os.path.dirname(__file__)
    key_file = os.path.join(current_folder, '.function_key')

    with open(key_file, 'wt') as writer:
        writer.write(function_key)


def upload(content):
    FUNCTION_APP = 'triggerstorage2'
    FUNCTION_NAME = 'upload'

    function_key = get_cached_function_key()
    if function_key is None:
        function_key = get_function_key_from_vault()
        cache_function_key(function_key)

    function_url = f'https://{FUNCTION_APP}.azurewebsites.net/api/{FUNCTION_NAME}?code={function_key}'

    return requests.post(function_url, data=content)


if __name__ == '__main__':
    response = upload('cloud: 29.05.2024')
    print(f'Got reponse {response.status_code}: {response.text}')
