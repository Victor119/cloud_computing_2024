#ifndef MONITORING_INFORMATION_THREAD_H
#define MONITORING_INFORMATION_THREAD_H

#include <time.h>

#define LOG_ROTATION_SECONDS 60 * 60
#define STATISTICS_GATHERING_INTERVAL_SECONDS 5
#define LOGS_DIR "./logs"
#define TEMPORARY_LOG_FILE_NAME LOGS_DIR"/.temporary.log"

int get_log_files(char *logs_metadata_file_name, int *num_log_files, time_t **monitoring_times);

void* monitoring_information_thread(void *args);

#endif // MONITORING_INFORMATION_H