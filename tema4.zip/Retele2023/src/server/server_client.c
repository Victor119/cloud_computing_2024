#define CLIENT_READ_BUFFER_SIZE 1024

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>
#include "operations/statistics/statistics.h"

void client_login(int socket_client, const char* buffer, int *login_status) {
    char login[1024], password[1024];
    int args_count = sscanf(buffer, "%s %s", login, password);

    if (args_count == 2) {
        if ((strcmp(login, "guest") == 0 && strcmp(password, "guest") == 0) || (strcmp(login, "jim") == 0 && strcmp(password, "jim") == 0)) {
            char msg[1024];
            strcpy(msg, "ok login\n");
            if (write(socket_client, msg, strlen(msg)) == -1) {
                perror("write");
                return;
            }
            
            printf("User logged in successfully: %s\n", login);

            *login_status = 1;
        } else {
            char msg[1024];
            strcpy(msg, "User login error\n");
            if (write(socket_client, msg, strlen(msg)) == -1) {
                perror("write");
            }
        }
    } else {
        char msg[1024];
        strcpy(msg, "User login error\n");
        if (write(socket_client, msg, strlen(msg)) == -1) {
            perror("write");
        }
    }
}

void fetch_statistics_for_client(int socket_client, const char* buffer, int *login_status) {
    time_t start_time, end_time;
    int args_count = sscanf(buffer, "%ld %ld", &start_time, &end_time);

    if (args_count != 2) {
        char msg[1024];
        strcpy(msg, "stat error\n");
        if (write(socket_client, msg, strlen(msg)) == -1) {
            perror("write");
        }
        return;
    }

    if (*login_status == 0) {
        char msg[1024];
        strcpy(msg, "login error\n");
        if (write(socket_client, msg, strlen(msg)) == -1) {
            perror("write");
        }
        return;
    }

    fetch_statistics(socket_client, start_time, end_time);
}


void* client_thread(void* arg) {
    int socket_client = *((int *)arg);
    int login_status = 0;
    int bytes_read;

    char buffer[CLIENT_READ_BUFFER_SIZE];

    while ((bytes_read = read(socket_client, buffer, sizeof(buffer))) > 0) {
        buffer[bytes_read] = '\0';

        if (strncmp(buffer, "login", 5) == 0) {
            client_login(socket_client, buffer + 6, &login_status);
        } else if (strncmp(buffer, "stat", 4) == 0) {
            fetch_statistics_for_client(socket_client, buffer + 4, &login_status);
        } else {
            char msg[1024];
            strcpy(msg, "unknown command: ");
            strcat(msg, buffer);

            if (write(socket_client, msg, strlen(msg)) == -1) {
                perror("write");
            }
        }
    }

    close(socket_client);
    
    pthread_exit(NULL);
}
