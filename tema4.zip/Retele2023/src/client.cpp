#include <arpa/inet.h>
#include <vector>
#include <chrono>
#include <cstring>
#include <cstdlib>
#include <fstream> 
#include <iomanip>
#include <iostream>
#include <regex>
#include <string>
#include <sys/socket.h>
#include <thread>
#include <unistd.h>

#include "matplotlibcpp.h"

namespace plt = matplotlibcpp;

// Forward declaration for get_lines
std::pair<std::vector<std::string>, std::string> get_lines(int sock, int num_lines, std::string last_buffer, size_t buffer_size);

class ChatClient {
private:
    std::string serverName;
    int serverPort;
    int clientSocket;
    
     std::ofstream messageLogFile; 

public:
    ChatClient(const std::string &serverName, int serverPort) : serverName(serverName), serverPort(serverPort) {
        clientSocket = socket(AF_INET, SOCK_STREAM, 0);
        messageLogFile.open("received_messages.txt", std::ios::out | std::ios::app);
    }

    bool connectToServer() {
        struct sockaddr_in serverAddr;
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_port = htons(serverPort);
        if (inet_pton(AF_INET, serverName.c_str(), &(serverAddr.sin_addr)) <= 0) {
            perror("inet_pton");
            return false;
        }

        if (connect(clientSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) == -1) {
            perror("connect");
            return false;
        }

        return true;
    }

    bool login(const std::string &login, const std::string &password) {
        std::string loginCommand = "login " + login + " " + password + "\n";
        ssize_t sentBytes = send(clientSocket, loginCommand.c_str(), loginCommand.length(), 0);

        if (sentBytes == -1) {
            perror("send");
            return false;
        }

        char response[256];
        ssize_t receivedBytes = recv(clientSocket, response, sizeof(response), 0);

        if (receivedBytes == -1) {
            perror("recv");
            return false;
        }

        response[receivedBytes] = '\0';
        std::string responseStr(response);

        if (responseStr.find("ok login") != std::string::npos) {
            std::cout << "Login successful" << std::endl;
            generateTextReport(); // Call the new function
            return true;
        } else {
            std::cout << "Login failed" << std::endl;
            return false;
        }
    }

    bool stat(int start_time, int end_time) {
        std::string statCommand = "stat " + std::to_string(start_time) + " " + std::to_string(end_time) + "\n";
        ssize_t sentBytes = send(clientSocket, statCommand.c_str(), statCommand.length(), 0);

        if (sentBytes == -1) {
            perror("send");
            return false;
        }

        std::this_thread::sleep_for(std::chrono::seconds(10)); // Change sleep duration to seconds

        char response[1024];
        ssize_t receivedBytes = recv(clientSocket, response, sizeof(response), 0);

        if (receivedBytes == -1) {
            perror("recv");
            return false;
        }

        response[receivedBytes] = '\0';
        std::string responseStr(response);

        // Print the received response without "Received: " prefix
        std::cout << responseStr << std::endl;

        return true;
    }

    void logoff() {
        std::string logoffCommand = "logoff\n";
        ssize_t sentBytes = send(clientSocket, logoffCommand.c_str(), logoffCommand.length(), 0);

        if (sentBytes == -1) {
            perror("send");
        }
    }

    void generateTextReport();
    
    
    std::tuple<std::vector<double>, std::vector<double>, std::vector<double>> send_time_memory_cpuload(const std::string& fileName);
    
    // Declaration of the generateGraphicalReport function
    void generateGraphicalReport(const std::vector<double>& vector_time, const std::vector<double>& vector_memory, const std::vector<double>& cpu_load);

    int getClientSocket() const {
        return clientSocket;
    }

    ~ChatClient() {
        close(clientSocket);
        messageLogFile.close();
    }
};

// Function declaration for get_lines
std::pair<std::vector<std::string>, std::string> get_lines(int sock, int num_lines, std::string last_buffer, size_t buffer_size);

// Implementation of get_lines function
std::pair<std::vector<std::string>, std::string> get_lines(int sock, int num_lines, std::string last_buffer, size_t buffer_size) {
    std::vector<std::string> lines;
    std::string buffer = last_buffer;

    while (lines.size() < num_lines) {
        size_t start = 0;
        std::regex newline_regex("\n");

        auto words_begin = std::sregex_iterator(buffer.begin(), buffer.end(), newline_regex);
        auto words_end = std::sregex_iterator();

        for (auto it = words_begin; it != words_end; ++it) {
            size_t position = it->position();

            lines.push_back(buffer.substr(start, position - start));
            start = position + 1;

            if (lines.size() == static_cast<size_t>(num_lines)) {
                break;
            }
        }

        last_buffer = buffer.substr(start);

        if (lines.size() < static_cast<size_t>(num_lines)) {
            try {
                char temp_buffer[buffer_size];
                ssize_t receivedBytes = recv(sock, temp_buffer, sizeof(temp_buffer), 0);

                if (receivedBytes <= 0) {
                    // No data available or an error occurred
                    break;
                }

                temp_buffer[receivedBytes] = '\0';
                buffer = last_buffer + temp_buffer;
            } catch (const std::exception &e) {
                // Handle the exception as needed
                break;
            }
        }
    }

    return {lines, last_buffer};
}

void ChatClient::generateTextReport() {
    std::thread readerThread([this]() {
        while (true) {
            char message[1024];
            ssize_t receivedBytes = recv(clientSocket, message, sizeof(message), 0);

            if (receivedBytes == -1) {
                perror("recv");
                break;
            } else if (receivedBytes == 0) {
                std::cout << "Serverul a închis conexiunea." << std::endl;
                break;
            }

            message[receivedBytes] = '\0';
            std::string messageStr(message);

            // Print the received message without "Received: " prefix
            std::cout << "Received: " << messageStr;

            // Save the message to the file
            messageLogFile << messageStr;

            // Check if the received message contains "Num Samples:"
            size_t found = messageStr.find("Num Samples:");

            if (found != std::string::npos) {
                // Extract and print the statistics
                auto lines = get_lines(clientSocket, 3, "", 1024);
                for (const auto &line : lines.first) {
                    std::cout << line << std::endl;
                    // Save the statistics to the file
                    messageLogFile << line << "\n";
                }
            }
        }
    });

    readerThread.detach();
}

void createSubsetFile(const std::string& inputFileName, const std::string& outputFileName, int startLine, int endLine) {
    std::ifstream inputFile(inputFileName);
    std::ofstream outputFile(outputFileName);

    if (!inputFile.is_open()) {
        std::cerr << "Error: Could not open input file '" << inputFileName << "'" << std::endl;
        return;
    }

    if (!outputFile.is_open()) {
        std::cerr << "Error: Could not create output file '" << outputFileName << "'" << std::endl;
        return;
    }

    std::string line;
    int currentLine = 1;

    while (std::getline(inputFile, line)) {
        if (currentLine >= startLine && currentLine <= endLine) {
            outputFile << line << "\n";
        }

        if (currentLine > endLine) {
            break;
        }

        ++currentLine;
    }

    inputFile.close();
    outputFile.close();

    std::cout << "Subset file '" << outputFileName << "' created successfully." << std::endl;
}

// Implementation of send_time_memory_cpuload function
std::tuple<std::vector<double>, std::vector<double>, std::vector<double>> ChatClient::send_time_memory_cpuload(const std::string& fileName) {
    std::ifstream inputFile(fileName);
    if (!inputFile.is_open()) {
        std::cerr << "Error: Could not open input file '" << fileName << "'" << std::endl;
        return {};
    }

    std::vector<std::vector<double>> values(3);
    std::string line;

    // Read the first three lines from the file
    for (int i = 0; i < 3 && std::getline(inputFile, line); ++i) {
        size_t labelPos = line.find(":");
        if (labelPos == std::string::npos) {
            continue; // Skip lines without a colon (':')
        }

        line = line.substr(labelPos + 1);
        std::istringstream iss(line);
        double value;

        // Process the current line
        while (iss >> value) {
            values[i].push_back(value);
        }
    }

    inputFile.close();

    // Return the obtained vectors
    return std::make_tuple(values[0], values[1], values[2]);
}


// Implementation of the generateGraphicalReport function
void ChatClient::generateGraphicalReport(const std::vector<double>& vector_time, const std::vector<double>& vector_memory, const std::vector<double>& cpu_load) {
     // Ensure that vectors have the same size
    if (vector_time.size() != vector_memory.size() || vector_time.size() != cpu_load.size()) {
        std::cerr << "Error: Vectors have different sizes." << std::endl;
        return;
    }

    // Set the precision for output
    std::cout << std::fixed << std::setprecision(2);

    // Figure 1: Memory Usage Over Time
    plt::figure();  // Create a new figure
    plt::plot(vector_time, vector_memory, "o-");
    plt::xlabel("Time");
    plt::ylabel("Memory");
    plt::title("Memory Usage Over Time");

    // Show the first plot
    plt::show();

    // Figure 2: CPU Load Over Time
    plt::figure();  // Create another new figure
    plt::plot(vector_time, cpu_load, "s-");
    plt::xlabel("Time");
    plt::ylabel("CPU Load");
    plt::title("CPU Load Over Time");

    // Show the second plot
    plt::show();
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: " << argv[0] << " <server_ip> <server_port>" << std::endl;
        return 1;
    }

    std::string serverIp = argv[1];
    int serverPort = std::stoi(argv[2]);

    ChatClient client(serverIp, serverPort);

    if (!client.connectToServer()) {
        std::cerr << "Failed to connect to the server." << std::endl;
        return 1;
    }

    std::string login, password;
    std::cout << "Enter login: ";
    std::cin >> login;
    std::cout << "Enter password: ";
    std::cin >> password;

    if (!client.login(login, password)) {
        return 1;
    }

    auto now = std::chrono::system_clock::now();
    auto end = std::chrono::system_clock::to_time_t(now);
    auto start = std::chrono::system_clock::to_time_t(now - std::chrono::minutes(2));

    int start_int = static_cast<int>(start);
    int end_int = static_cast<int>(end);

    client.stat(start_int, end_int);
    client.logoff();
    
    std::string response;
    std::cout << "Afiseaza grafic? (scrie yes sau no)";
    std::cin >> response;
    
    if(response == "yes"){

    	createSubsetFile("received_messages.txt", "received_messages2.txt", 2, 4);

    	auto [vector_time, vector_memory, vector_cpuload] = client.send_time_memory_cpuload("received_messages2.txt");
	
    	client.generateGraphicalReport(vector_time, vector_memory, vector_cpuload);
	}
    else{
    	client.logoff();
    }
    return 0;
}

