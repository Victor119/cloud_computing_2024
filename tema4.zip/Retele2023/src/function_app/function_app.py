import azure.functions as func
import logging

app = func.FunctionApp()

@app.function_name(name="blob_trigger")
@app.blob_trigger(arg_name="tema4cc",
                  path="/",
                  connection="CONNECTION_STRING")
def blob_trigger(uploaded_blob: func.InputStream):
    logging.log(
        "Triggered blob function! "
        f"Blob name: {uploaded_blob.name}."
        f"Blob size: {uploaded_blob.size}."
    )
