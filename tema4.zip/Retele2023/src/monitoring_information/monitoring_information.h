#ifndef MONITORING_INFORMATION_H
#define MONITORING_INFORMATION_H

#include <time.h>

#include "../system_information/system_information.h"
#include "../process/process.h"
#include "../user/user.h"
#include "../network_connection/network_connection.h"

struct monitoring_information {
    time_t monitoring_time;
    struct system_information *system_information;

    int number_of_processes;
    struct process *processes;

    int number_of_users;
    struct user *users;
};

// Monitoring information methods

// Read the monitoring information from a log file
int monitoring_information_log(FILE *file, struct monitoring_information *monitoring_log);

// Write the monitoring information to a log file
int monitoring_information_from_log(FILE *file, struct monitoring_information *monitoring_log);

// Release the memory allocated by the monitoring information
void free_monitoring_information(struct monitoring_information * monitoring_information);


// Monitoring information utils methods

void fetch_monitoring_information(time_t monitoring_time, struct monitoring_information *monitoring_information);

#endif // MONITORING_INFORMATION_H
